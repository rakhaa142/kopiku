import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { DatabaseState, User, Menu, Material, Recipe, Transaction, Review } from '../types';
import { toast } from 'react-hot-toast';

// Enhanced database with cloud-like persistence
const DB_KEY = 'kopikoe_database_v2';
const BACKUP_KEY = 'kopikoe_backup_v2';

interface DatabaseContextType extends DatabaseState {
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>) => Promise<boolean>;
  addMenu: (menu: Omit<Menu, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMenu: (id: string, menu: Partial<Menu>) => void;
  deleteMenu: (id: string) => void;
  addMaterial: (material: Omit<Material, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMaterial: (id: string, material: Partial<Material>) => void;
  deleteMaterial: (id: string) => void;
  addRecipe: (recipe: Omit<Recipe, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateRecipe: (id: string, recipe: Partial<Recipe>) => void;
  deleteRecipe: (id: string) => void;
  addTransaction: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransaction: (id: string, transaction: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;
  approveReview: (id: string) => void;
  deleteReview: (id: string) => void;
  getUsersByRole: (role: User['role']) => User[];
  getUsersByParent: (parentId: string) => User[];
  deleteUser: (id: string) => boolean;
  exportToExcel: () => void;
  createBackup: () => void;
  restoreBackup: () => boolean;
}

type DatabaseAction =
  | { type: 'LOAD_DATA'; payload: DatabaseState }
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'DELETE_USER'; payload: string }
  | { type: 'ADD_MENU'; payload: Menu }
  | { type: 'UPDATE_MENU'; payload: { id: string; data: Partial<Menu> } }
  | { type: 'DELETE_MENU'; payload: string }
  | { type: 'ADD_MATERIAL'; payload: Material }
  | { type: 'UPDATE_MATERIAL'; payload: { id: string; data: Partial<Material> } }
  | { type: 'DELETE_MATERIAL'; payload: string }
  | { type: 'ADD_RECIPE'; payload: Recipe }
  | { type: 'UPDATE_RECIPE'; payload: { id: string; data: Partial<Recipe> } }
  | { type: 'DELETE_RECIPE'; payload: string }
  | { type: 'ADD_TRANSACTION'; payload: Transaction }
  | { type: 'UPDATE_TRANSACTION'; payload: { id: string; data: Partial<Transaction> } }
  | { type: 'DELETE_TRANSACTION'; payload: string }
  | { type: 'ADD_REVIEW'; payload: Review }
  | { type: 'APPROVE_REVIEW'; payload: string }
  | { type: 'DELETE_REVIEW'; payload: string };

const initialState: DatabaseState = {
  users: [
    {
      id: 'owner-001',
      username: 'owner',
      password: 'kopikoe123',
      role: 'owner',
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ],
  menus: [],
  materials: [],
  recipes: [],
  transactions: [],
  reviews: [],
  currentUser: null
};

function databaseReducer(state: DatabaseState, action: DatabaseAction): DatabaseState {
  switch (action.type) {
    case 'LOAD_DATA':
      return action.payload;
    
    case 'LOGIN':
      return { ...state, currentUser: action.payload };
    
    case 'LOGOUT':
      return { ...state, currentUser: null };
    
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    
    case 'DELETE_USER':
      return { 
        ...state, 
        users: state.users.filter(user => user.id !== action.payload)
      };
    
    case 'ADD_MENU':
      return { ...state, menus: [...state.menus, action.payload] };
    
    case 'UPDATE_MENU':
      return {
        ...state,
        menus: state.menus.map(menu =>
          menu.id === action.payload.id 
            ? { ...menu, ...action.payload.data, updatedAt: new Date() }
            : menu
        )
      };
    
    case 'DELETE_MENU':
      return { ...state, menus: state.menus.filter(menu => menu.id !== action.payload) };
    
    case 'ADD_MATERIAL':
      return { ...state, materials: [...state.materials, action.payload] };
    
    case 'UPDATE_MATERIAL':
      return {
        ...state,
        materials: state.materials.map(material =>
          material.id === action.payload.id 
            ? { ...material, ...action.payload.data, updatedAt: new Date() }
            : material
        )
      };
    
    case 'DELETE_MATERIAL':
      return { ...state, materials: state.materials.filter(material => material.id !== action.payload) };
    
    case 'ADD_RECIPE':
      return { ...state, recipes: [...state.recipes, action.payload] };
    
    case 'UPDATE_RECIPE':
      return {
        ...state,
        recipes: state.recipes.map(recipe =>
          recipe.id === action.payload.id 
            ? { ...recipe, ...action.payload.data, updatedAt: new Date() }
            : recipe
        )
      };
    
    case 'DELETE_RECIPE':
      return { ...state, recipes: state.recipes.filter(recipe => recipe.id !== action.payload) };
    
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [...state.transactions, action.payload] };
    
    case 'UPDATE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map(transaction =>
          transaction.id === action.payload.id 
            ? { ...transaction, ...action.payload.data }
            : transaction
        )
      };
    
    case 'DELETE_TRANSACTION':
      return { ...state, transactions: state.transactions.filter(transaction => transaction.id !== action.payload) };
    
    case 'ADD_REVIEW':
      return { ...state, reviews: [...state.reviews, action.payload] };
    
    case 'APPROVE_REVIEW':
      return {
        ...state,
        reviews: state.reviews.map(review =>
          review.id === action.payload 
            ? { ...review, isApproved: true }
            : review
        )
      };
    
    case 'DELETE_REVIEW':
      return { ...state, reviews: state.reviews.filter(review => review.id !== action.payload) };
    
    default:
      return state;
  }
}

const DatabaseContext = createContext<DatabaseContextType | null>(null);

export function DatabaseProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(databaseReducer, initialState);

  // Enhanced data persistence with automatic backup
  useEffect(() => {
    const savedData = localStorage.getItem(DB_KEY);
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        const processedData = {
          ...parsedData,
          users: parsedData.users?.map((user: any) => ({
            ...user,
            createdAt: new Date(user.createdAt),
            updatedAt: new Date(user.updatedAt)
          })) || initialState.users,
          menus: parsedData.menus?.map((menu: any) => ({
            ...menu,
            createdAt: new Date(menu.createdAt),
            updatedAt: new Date(menu.updatedAt)
          })) || [],
          materials: parsedData.materials?.map((material: any) => ({
            ...material,
            createdAt: new Date(material.createdAt),
            updatedAt: new Date(material.updatedAt)
          })) || [],
          recipes: parsedData.recipes?.map((recipe: any) => ({
            ...recipe,
            createdAt: new Date(recipe.createdAt),
            updatedAt: new Date(recipe.updatedAt)
          })) || [],
          transactions: parsedData.transactions?.map((transaction: any) => ({
            ...transaction,
            createdAt: new Date(transaction.createdAt)
          })) || [],
          reviews: parsedData.reviews?.map((review: any) => ({
            ...review,
            createdAt: new Date(review.createdAt)
          })) || [],
          currentUser: null
        };
        dispatch({ type: 'LOAD_DATA', payload: processedData });
      } catch (error) {
        console.error('Error loading data from localStorage:', error);
        toast.error('Error loading saved data');
      }
    }
  }, []);

  // Save data with automatic backup
  useEffect(() => {
    localStorage.setItem(DB_KEY, JSON.stringify(state));
    
    // Create automatic backup every 10 saves
    const saveCount = parseInt(localStorage.getItem('kopikoe_save_count') || '0') + 1;
    localStorage.setItem('kopikoe_save_count', saveCount.toString());
    
    if (saveCount % 10 === 0) {
      localStorage.setItem(BACKUP_KEY, JSON.stringify({
        ...state,
        backupDate: new Date().toISOString()
      }));
    }
  }, [state]);

  const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const user = state.users.find(
          u => u.username === username && u.password === password
        );
        
        if (user) {
          dispatch({ type: 'LOGIN', payload: user });
          toast.success(`Selamat datang, ${user.username}!`);
          resolve(true);
        } else {
          toast.error('Username atau password salah!');
          resolve(false);
        }
      }, 300);
    });
  };

  const logout = () => {
    dispatch({ type: 'LOGOUT' });
    toast.success('Berhasil logout');
  };

  const register = async (userData: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<boolean> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const existingUser = state.users.find(u => u.username === userData.username);
        if (existingUser) {
          toast.error('Username sudah digunakan!');
          resolve(false);
          return;
        }

        const newUser: User = {
          ...userData,
          id: generateId(),
          createdAt: new Date(),
          updatedAt: new Date()
        };

        dispatch({ type: 'ADD_USER', payload: newUser });
        toast.success(`Akun ${userData.username} berhasil dibuat!`);
        resolve(true);
      }, 300);
    });
  };

  const addMenu = (menuData: Omit<Menu, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newMenu: Menu = {
      ...menuData,
      id: generateId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    dispatch({ type: 'ADD_MENU', payload: newMenu });
    toast.success(`Menu ${menuData.name} berhasil ditambahkan!`);
  };

  const updateMenu = (id: string, menuData: Partial<Menu>) => {
    dispatch({ type: 'UPDATE_MENU', payload: { id, data: menuData } });
    toast.success('Menu berhasil diperbarui!');
  };

  const deleteMenu = (id: string) => {
    const menu = state.menus.find(m => m.id === id);
    if (menu) {
      dispatch({ type: 'DELETE_MENU', payload: id });
      toast.success(`Menu ${menu.name} berhasil dihapus!`);
    }
  };

  const addMaterial = (materialData: Omit<Material, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newMaterial: Material = {
      ...materialData,
      id: generateId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    dispatch({ type: 'ADD_MATERIAL', payload: newMaterial });
    toast.success(`Bahan ${materialData.name} berhasil ditambahkan!`);
  };

  const updateMaterial = (id: string, materialData: Partial<Material>) => {
    dispatch({ type: 'UPDATE_MATERIAL', payload: { id, data: materialData } });
    toast.success('Bahan berhasil diperbarui!');
  };

  const deleteMaterial = (id: string) => {
    const material = state.materials.find(m => m.id === id);
    if (material) {
      dispatch({ type: 'DELETE_MATERIAL', payload: id });
      toast.success(`Bahan ${material.name} berhasil dihapus!`);
    }
  };

  const addRecipe = (recipeData: Omit<Recipe, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newRecipe: Recipe = {
      ...recipeData,
      id: generateId(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    dispatch({ type: 'ADD_RECIPE', payload: newRecipe });
    toast.success(`Resep ${recipeData.menuName} berhasil ditambahkan!`);
  };

  const updateRecipe = (id: string, recipeData: Partial<Recipe>) => {
    dispatch({ type: 'UPDATE_RECIPE', payload: { id, data: recipeData } });
    toast.success('Resep berhasil diperbarui!');
  };

  const deleteRecipe = (id: string) => {
    const recipe = state.recipes.find(r => r.id === id);
    if (recipe) {
      dispatch({ type: 'DELETE_RECIPE', payload: id });
      toast.success(`Resep ${recipe.menuName} berhasil dihapus!`);
    }
  };

  const addTransaction = (transactionData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: generateId(),
      createdAt: new Date()
    };
    dispatch({ type: 'ADD_TRANSACTION', payload: newTransaction });
    
    const typeText = transactionData.type === 'income' ? 'Pemasukan' : 'Pengeluaran';
    toast.success(`${typeText} berhasil ditambahkan!`);
  };

  const updateTransaction = (id: string, transactionData: Partial<Transaction>) => {
    dispatch({ type: 'UPDATE_TRANSACTION', payload: { id, data: transactionData } });
    toast.success('Transaksi berhasil diperbarui!');
  };

  const deleteTransaction = (id: string) => {
    const transaction = state.transactions.find(t => t.id === id);
    if (transaction) {
      dispatch({ type: 'DELETE_TRANSACTION', payload: id });
      const typeText = transaction.type === 'income' ? 'Pemasukan' : 'Pengeluaran';
      toast.success(`${typeText} berhasil dihapus!`);
    }
  };

  const addReview = (reviewData: Omit<Review, 'id' | 'createdAt'>) => {
    const newReview: Review = {
      ...reviewData,
      id: generateId(),
      createdAt: new Date()
    };
    dispatch({ type: 'ADD_REVIEW', payload: newReview });
    toast.success('Review berhasil dikirim! Menunggu persetujuan admin.');
  };

  const approveReview = (id: string) => {
    dispatch({ type: 'APPROVE_REVIEW', payload: id });
    toast.success('Review berhasil disetujui!');
  };

  const deleteReview = (id: string) => {
    const review = state.reviews.find(r => r.id === id);
    if (review) {
      dispatch({ type: 'DELETE_REVIEW', payload: id });
      toast.success(`Review dari ${review.customerName} berhasil dihapus!`);
    }
  };

  const getUsersByRole = (role: User['role']) => {
    return state.users.filter(user => user.role === role);
  };

  const getUsersByParent = (parentId: string) => {
    return state.users.filter(user => user.parentId === parentId);
  };

  const deleteUser = (id: string): boolean => {
    if (id === state.currentUser?.id) {
      toast.error('Tidak dapat menghapus akun yang sedang aktif!');
      return false;
    }
    
    const user = state.users.find(u => u.id === id);
    if (user) {
      dispatch({ type: 'DELETE_USER', payload: id });
      toast.success(`Akun ${user.username} berhasil dihapus!`);
      return true;
    }
    return false;
  };

  const exportToExcel = () => {
    const data = {
      menus: state.menus,
      materials: state.materials,
      recipes: state.recipes,
      transactions: state.transactions,
      reviews: state.reviews,
      exportDate: new Date().toISOString(),
      version: '2.0'
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `kopikoe-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success('Data berhasil diekspor!');
  };

  const createBackup = () => {
    const backupData = {
      ...state,
      backupDate: new Date().toISOString(),
      version: '2.0'
    };
    
    localStorage.setItem(BACKUP_KEY, JSON.stringify(backupData));
    toast.success('Backup berhasil dibuat!');
  };

  const restoreBackup = (): boolean => {
    try {
      const backupData = localStorage.getItem(BACKUP_KEY);
      if (!backupData) {
        toast.error('Tidak ada backup yang ditemukan!');
        return false;
      }

      const parsedBackup = JSON.parse(backupData);
      const processedData = {
        ...parsedBackup,
        users: parsedBackup.users?.map((user: any) => ({
          ...user,
          createdAt: new Date(user.createdAt),
          updatedAt: new Date(user.updatedAt)
        })) || initialState.users,
        currentUser: null
      };

      dispatch({ type: 'LOAD_DATA', payload: processedData });
      toast.success('Data berhasil dipulihkan dari backup!');
      return true;
    } catch (error) {
      toast.error('Gagal memulihkan data dari backup!');
      return false;
    }
  };

  const value: DatabaseContextType = {
    ...state,
    login,
    logout,
    register,
    addMenu,
    updateMenu,
    deleteMenu,
    addMaterial,
    updateMaterial,
    deleteMaterial,
    addRecipe,
    updateRecipe,
    deleteRecipe,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addReview,
    approveReview,
    deleteReview,
    getUsersByRole,
    getUsersByParent,
    deleteUser,
    exportToExcel,
    createBackup,
    restoreBackup
  };

  return (
    <DatabaseContext.Provider value={value}>
      {children}
    </DatabaseContext.Provider>
  );
}

export function useDatabase() {
  const context = useContext(DatabaseContext);
  if (!context) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
}