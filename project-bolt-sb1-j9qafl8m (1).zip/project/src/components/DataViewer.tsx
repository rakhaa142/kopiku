import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { X, Eye, Search, Filter, Trash2, Calendar, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { Transaction, TimeFilter } from '../types';
import { format, startOfDay, startOfMonth, startOfYear, subMonths, subYears } from 'date-fns';
import { id } from 'date-fns/locale';

interface DataViewerProps {
  onClose: () => void;
}

const DataViewer: React.FC<DataViewerProps> = ({ onClose }) => {
  const { transactions, deleteTransaction, currentUser, users } = useDatabase();
  const [searchTerm, setSearchTerm] = useState('');
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('today');
  const [typeFilter, setTypeFilter] = useState<'all' | 'income' | 'expense'>('all');

  // Filter transactions based on user permissions
  const userTransactions = useMemo(() => {
    if (!currentUser) return [];
    
    return transactions.filter(t => {
      if (currentUser.role === 'owner') return true;
      if (currentUser.role === 'franchise') {
        return t.createdBy === currentUser.id || t.createdByRole === 'employee';
      }
      return t.createdBy === currentUser.id;
    });
  }, [transactions, currentUser]);

  // Apply filters
  const filteredTransactions = useMemo(() => {
    let filtered = userTransactions;

    // Time filter
    const now = new Date();
    filtered = filtered.filter(t => {
      const transactionDate = new Date(t.createdAt);
      switch (timeFilter) {
        case 'today':
          return transactionDate >= startOfDay(now);
        case 'thisMonth':
          return transactionDate >= startOfMonth(now);
        case 'lastMonth':
          const lastMonth = subMonths(now, 1);
          return transactionDate >= startOfMonth(lastMonth) && transactionDate < startOfMonth(now);
        case 'thisYear':
          return transactionDate >= startOfYear(now);
        case 'lastYear':
          const lastYear = subYears(now, 1);
          return transactionDate >= startOfYear(lastYear) && transactionDate < startOfYear(now);
        default:
          return true;
      }
    });

    // Type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(t => t.type === typeFilter);
    }

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(t =>
        (t.menuName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (t.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.paymentMethod?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort by date (newest first)
    return filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [userTransactions, timeFilter, typeFilter, searchTerm]);

  const handleDelete = (transaction: Transaction) => {
    const typeText = transaction.type === 'income' ? 'pemasukan' : 'pengeluaran';
    const itemName = transaction.menuName || transaction.description || 'transaksi';
    
    if (window.confirm(`Apakah Anda yakin ingin menghapus ${typeText} "${itemName}"?`)) {
      deleteTransaction(transaction.id);
    }
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const getCreatorName = (createdBy: string): string => {
    const user = users.find(u => u.id === createdBy);
    return user?.username || 'Unknown';
  };

  // Calculate summary
  const summary = useMemo(() => {
    const totalIncome = filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalExpense = filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const totalCups = filteredTransactions
      .filter(t => t.type === 'income' && t.cups)
      .reduce((sum, t) => sum + (t.cups || 0), 0);

    return {
      totalIncome,
      totalExpense,
      netProfit: totalIncome - totalExpense,
      totalCups,
      totalTransactions: filteredTransactions.length
    };
  }, [filteredTransactions]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-600 to-teal-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Eye className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Data Transaksi</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Filters */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Cari transaksi..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Time Filter */}
            <select
              value={timeFilter}
              onChange={(e) => setTimeFilter(e.target.value as TimeFilter)}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="today">Hari Ini</option>
              <option value="thisMonth">Bulan Ini</option>
              <option value="lastMonth">Bulan Lalu</option>
              <option value="thisYear">Tahun Ini</option>
              <option value="lastYear">Tahun Lalu</option>
            </select>

            {/* Type Filter */}
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as 'all' | 'income' | 'expense')}
              className="px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="all">Semua Transaksi</option>
              <option value="income">Pemasukan</option>
              <option value="expense">Pengeluaran</option>
            </select>

            {/* Results Count */}
            <div className="flex items-center justify-center bg-teal-50 rounded-xl px-4 py-3 border border-teal-200">
              <span className="text-teal-700 font-medium">
                {filteredTransactions.length} transaksi
              </span>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-green-50 p-4 rounded-xl border border-green-200">
              <div className="flex items-center space-x-2 mb-1">
                <TrendingUp className="text-green-600" size={16} />
                <span className="text-sm text-green-700 font-medium">Pemasukan</span>
              </div>
              <p className="text-lg font-bold text-green-600">
                {formatCurrency(summary.totalIncome)}
              </p>
            </div>

            <div className="bg-red-50 p-4 rounded-xl border border-red-200">
              <div className="flex items-center space-x-2 mb-1">
                <TrendingDown className="text-red-600" size={16} />
                <span className="text-sm text-red-700 font-medium">Pengeluaran</span>
              </div>
              <p className="text-lg font-bold text-red-600">
                {formatCurrency(summary.totalExpense)}
              </p>
            </div>

            <div className={`p-4 rounded-xl border ${summary.netProfit >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
              <div className="flex items-center space-x-2 mb-1">
                <DollarSign className={summary.netProfit >= 0 ? 'text-blue-600' : 'text-orange-600'} size={16} />
                <span className={`text-sm font-medium ${summary.netProfit >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
                  Keuntungan
                </span>
              </div>
              <p className={`text-lg font-bold ${summary.netProfit >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>
                {formatCurrency(summary.netProfit)}
              </p>
            </div>

            <div className="bg-purple-50 p-4 rounded-xl border border-purple-200">
              <div className="flex items-center space-x-2 mb-1">
                <Calendar className="text-purple-600" size={16} />
                <span className="text-sm text-purple-700 font-medium">Total Cup</span>
              </div>
              <p className="text-lg font-bold text-purple-600">
                {summary.totalCups.toLocaleString('id-ID')}
              </p>
            </div>

            <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
              <div className="flex items-center space-x-2 mb-1">
                <Filter className="text-gray-600" size={16} />
                <span className="text-sm text-gray-700 font-medium">Transaksi</span>
              </div>
              <p className="text-lg font-bold text-gray-600">
                {summary.totalTransactions}
              </p>
            </div>
          </div>

          {/* Transactions Table */}
          <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Tanggal</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Jenis</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Item</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Jumlah</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Cup</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Pembayaran</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Dibuat</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-6 py-12 text-center">
                        <Eye className="mx-auto text-gray-400 mb-4" size={48} />
                        <p className="text-gray-500 text-lg">
                          {searchTerm || typeFilter !== 'all' ? 'Tidak ada transaksi yang sesuai filter' : 'Belum ada transaksi'}
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((transaction, index) => (
                      <motion.tr
                        key={transaction.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.02 }}
                        className="hover:bg-gray-50 transition-colors duration-200"
                      >
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {format(new Date(transaction.createdAt), 'dd/MM/yyyy HH:mm', { locale: id })}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                            transaction.type === 'income'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {transaction.type === 'income' ? 'Pemasukan' : 'Pengeluaran'}
                          </span>
                          {transaction.isWholesale && (
                            <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                              Grosir
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          <div>
                            <p className="font-medium">
                              {transaction.menuName || transaction.description || '-'}
                            </p>
                            {transaction.description && transaction.menuName && (
                              <p className="text-gray-500 text-xs mt-1">{transaction.description}</p>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm font-semibold">
                          <span className={transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}>
                            {formatCurrency(transaction.amount)}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {transaction.cups ? `${transaction.cups.toLocaleString('id-ID')} cup` : '-'}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {transaction.paymentMethod ? (
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                              transaction.paymentMethod === 'qris'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {transaction.paymentMethod.toUpperCase()}
                            </span>
                          ) : '-'}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500">
                          <div>
                            <p>{getCreatorName(transaction.createdBy)}</p>
                            <p className="text-xs">
                              ({transaction.createdByRole === 'owner' ? 'Owner' : 
                                transaction.createdByRole === 'franchise' ? 'Franchise' : 'Karyawan'})
                            </p>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => handleDelete(transaction)}
                            className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors duration-200"
                            title="Hapus transaksi"
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </motion.tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default DataViewer;