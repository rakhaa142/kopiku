import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, Edit3, Trash2, Search, Coffee } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { Menu } from '../types';

interface MenuManagementProps {
  onClose: () => void;
}

const MenuManagement: React.FC<MenuManagementProps> = ({ onClose }) => {
  const { menus, addMenu, updateMenu, deleteMenu, currentUser } = useDatabase();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingMenu, setEditingMenu] = useState<Menu | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: ''
  });

  // Filter menus based on user permissions
  const userMenus = menus.filter(menu => {
    if (currentUser?.role === 'owner') return true;
    return menu.createdBy === currentUser?.id;
  });

  const filteredMenus = userMenus.filter(menu =>
    menu.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (menu.category || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setFormData({ name: '', price: '', category: '' });
    setIsAdding(false);
    setEditingMenu(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.price.trim()) {
      return;
    }

    const price = parseFloat(formData.price.replace(/\./g, ''));
    
    if (editingMenu) {
      updateMenu(editingMenu.id, {
        name: formData.name.trim(),
        price,
        category: formData.category.trim() || undefined
      });
    } else {
      addMenu({
        name: formData.name.trim(),
        price,
        category: formData.category.trim() || undefined,
        createdBy: currentUser?.id || ''
      });
    }
    
    resetForm();
  };

  const handleEdit = (menu: Menu) => {
    setEditingMenu(menu);
    setFormData({
      name: menu.name,
      price: menu.price.toString(),
      category: menu.category || ''
    });
    setIsAdding(true);
  };

  const handleDelete = (menu: Menu) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus menu "${menu.name}"?`)) {
      deleteMenu(menu.id);
    }
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatInputCurrency = (value: string): string => {
    const number = value.replace(/\D/g, '');
    return new Intl.NumberFormat('id-ID').format(parseInt(number) || 0);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Coffee className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Kelola Menu</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Search & Add Button */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Cari menu..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors duration-200"
            >
              <Plus size={20} />
              <span>Tambah Menu</span>
            </button>
          </div>

          {/* Add/Edit Form */}
          {isAdding && (
            <motion.form
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmit}
              className="bg-purple-50 rounded-2xl p-6 mb-6 border border-purple-200"
            >
              <h3 className="text-lg font-semibold text-purple-800 mb-4">
                {editingMenu ? 'Edit Menu' : 'Tambah Menu Baru'}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nama Menu *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="Nama menu"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Harga *
                  </label>
                  <input
                    type="text"
                    value={formatInputCurrency(formData.price)}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value.replace(/\./g, '') }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="0"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kategori
                  </label>
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
                    placeholder="Kategori menu"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors duration-200"
                >
                  {editingMenu ? 'Update Menu' : 'Tambah Menu'}
                </button>
              </div>
            </motion.form>
          )}

          {/* Menu List */}
          <div className="space-y-4">
            {filteredMenus.length === 0 ? (
              <div className="text-center py-12">
                <Coffee className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">
                  {searchTerm ? 'Menu tidak ditemukan' : 'Belum ada menu'}
                </p>
              </div>
            ) : (
              filteredMenus.map((menu, index) => (
                <motion.div
                  key={menu.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-200"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{menu.name}</h3>
                        {menu.category && (
                          <span className="px-3 py-1 bg-purple-100 text-purple-800 text-sm rounded-full font-medium">
                            {menu.category}
                          </span>
                        )}
                      </div>
                      <p className="text-xl font-bold text-purple-600">{formatCurrency(menu.price)}</p>
                      <p className="text-sm text-gray-500 mt-1">
                        Dibuat: {new Date(menu.createdAt).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleEdit(menu)}
                        className="p-2 bg-blue-100 text-blue-600 rounded-xl hover:bg-blue-200 transition-colors duration-200"
                        title="Edit menu"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(menu)}
                        className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors duration-200"
                        title="Hapus menu"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default MenuManagement;