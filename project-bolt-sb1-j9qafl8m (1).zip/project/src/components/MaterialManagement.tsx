import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, Edit3, Trash2, Search, Package } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { Material } from '../types';

interface MaterialManagementProps {
  onClose: () => void;
}

const MaterialManagement: React.FC<MaterialManagementProps> = ({ onClose }) => {
  const { materials, addMaterial, updateMaterial, deleteMaterial, currentUser } = useDatabase();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState<Material | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    totalPrice: '',
    totalWeight: ''
  });

  // Filter materials based on user permissions
  const userMaterials = materials.filter(material => {
    if (currentUser?.role === 'owner') return true;
    return material.createdBy === currentUser?.id;
  });

  const filteredMaterials = userMaterials.filter(material =>
    material.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setFormData({ name: '', totalPrice: '', totalWeight: '' });
    setIsAdding(false);
    setEditingMaterial(null);
  };

  const calculatePricePerGram = (totalPrice: number, totalWeight: number): number => {
    return totalWeight > 0 ? totalPrice / totalWeight : 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.totalPrice.trim() || !formData.totalWeight.trim()) {
      return;
    }

    const totalPrice = parseFloat(formData.totalPrice.replace(/\./g, ''));
    const totalWeight = parseFloat(formData.totalWeight.replace(/\./g, ''));
    const pricePerGram = calculatePricePerGram(totalPrice, totalWeight);
    
    if (editingMaterial) {
      updateMaterial(editingMaterial.id, {
        name: formData.name.trim(),
        totalPrice,
        totalWeight,
        pricePerGram
      });
    } else {
      addMaterial({
        name: formData.name.trim(),
        totalPrice,
        totalWeight,
        pricePerGram,
        createdBy: currentUser?.id || ''
      });
    }
    
    resetForm();
  };

  const handleEdit = (material: Material) => {
    setEditingMaterial(material);
    setFormData({
      name: material.name,
      totalPrice: material.totalPrice.toString(),
      totalWeight: material.totalWeight.toString()
    });
    setIsAdding(true);
  };

  const handleDelete = (material: Material) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus bahan "${material.name}"?`)) {
      deleteMaterial(material.id);
    }
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatNumber = (value: string): string => {
    const number = value.replace(/\D/g, '');
    return new Intl.NumberFormat('id-ID').format(parseInt(number) || 0);
  };

  // Live calculation preview
  const previewPricePerGram = () => {
    const price = parseFloat(formData.totalPrice.replace(/\./g, '')) || 0;
    const weight = parseFloat(formData.totalWeight.replace(/\./g, '')) || 0;
    return calculatePricePerGram(price, weight);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-600 to-orange-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Package className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Kelola Bahan</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Search & Add Button */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Cari bahan..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center space-x-2 px-6 py-3 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-700 transition-colors duration-200"
            >
              <Plus size={20} />
              <span>Tambah Bahan</span>
            </button>
          </div>

          {/* Add/Edit Form */}
          {isAdding && (
            <motion.form
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmit}
              className="bg-orange-50 rounded-2xl p-6 mb-6 border border-orange-200"
            >
              <h3 className="text-lg font-semibold text-orange-800 mb-4">
                {editingMaterial ? 'Edit Bahan' : 'Tambah Bahan Baru'}
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nama Bahan *
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="Nama bahan"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Harga Total *
                  </label>
                  <input
                    type="text"
                    value={formatNumber(formData.totalPrice)}
                    onChange={(e) => setFormData(prev => ({ ...prev, totalPrice: e.target.value.replace(/\./g, '') }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="0"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Berat Total (gram) *
                  </label>
                  <input
                    type="text"
                    value={formatNumber(formData.totalWeight)}
                    onChange={(e) => setFormData(prev => ({ ...prev, totalWeight: e.target.value.replace(/\./g, '') }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                    placeholder="0"
                    required
                  />
                </div>
              </div>

              {/* Live Calculation Preview */}
              {(formData.totalPrice || formData.totalWeight) && (
                <div className="mt-4 p-4 bg-white rounded-xl border border-orange-200">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Preview Perhitungan:</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Harga Total:</span>
                      <p className="font-semibold text-orange-600">
                        {formatCurrency(parseFloat(formData.totalPrice.replace(/\./g, '')) || 0)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">Berat Total:</span>
                      <p className="font-semibold text-orange-600">
                        {formatNumber(formData.totalWeight)} gram
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">Harga per Gram:</span>
                      <p className="font-semibold text-green-600">
                        {formatCurrency(previewPricePerGram())}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-orange-600 text-white rounded-xl font-semibold hover:bg-orange-700 transition-colors duration-200"
                >
                  {editingMaterial ? 'Update Bahan' : 'Tambah Bahan'}
                </button>
              </div>
            </motion.form>
          )}

          {/* Material List */}
          <div className="space-y-4">
            {filteredMaterials.length === 0 ? (
              <div className="text-center py-12">
                <Package className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">
                  {searchTerm ? 'Bahan tidak ditemukan' : 'Belum ada bahan'}
                </p>
              </div>
            ) : (
              filteredMaterials.map((material, index) => (
                <motion.div
                  key={material.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-200"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-3">{material.name}</h3>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-orange-50 p-3 rounded-xl">
                          <p className="text-sm text-gray-600 mb-1">Harga Total</p>
                          <p className="text-lg font-bold text-orange-600">
                            {formatCurrency(material.totalPrice)}
                          </p>
                        </div>
                        
                        <div className="bg-blue-50 p-3 rounded-xl">
                          <p className="text-sm text-gray-600 mb-1">Berat Total</p>
                          <p className="text-lg font-bold text-blue-600">
                            {material.totalWeight.toLocaleString('id-ID')} gram
                          </p>
                        </div>
                        
                        <div className="bg-green-50 p-3 rounded-xl">
                          <p className="text-sm text-gray-600 mb-1">Harga per Gram</p>
                          <p className="text-lg font-bold text-green-600">
                            {formatCurrency(material.pricePerGram)}
                          </p>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-500 mt-3">
                        Dibuat: {new Date(material.createdAt).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => handleEdit(material)}
                        className="p-2 bg-blue-100 text-blue-600 rounded-xl hover:bg-blue-200 transition-colors duration-200"
                        title="Edit bahan"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(material)}
                        className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors duration-200"
                        title="Hapus bahan"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default MaterialManagement;