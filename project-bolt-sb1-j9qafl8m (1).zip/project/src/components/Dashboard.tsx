import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calculator, 
  LogOut, 
  Download, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Coffee,
  Package,
  ChefHat,
  Receipt,
  BarChart3,
  Plus,
  Settings,
  Calendar,
  DollarSign,
  ShoppingCart,
  User,
  Crown,
  Building2,
  UserPlus,
  Trash2,
  Edit3,
  Eye,
  Search,
  Filter,
  Menu,
  X,
  Activity,
  Zap
} from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { TimeFilter, Analytics } from '../types';
import { format, startOfDay, startOfWeek, startOfMonth, startOfYear, subMonths, subYears } from 'date-fns';
import { id } from 'date-fns/locale';
import FloatingCalculator from './FloatingCalculator';
import MenuManagement from './MenuManagement';
import MaterialManagement from './MaterialManagement';
import RecipeManagement from './RecipeManagement';
import TransactionManagement from './TransactionManagement';
import AccountManagement from './AccountManagement';
import DataViewer from './DataViewer';

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const { currentUser, logout, exportToExcel, transactions, menus, materials, recipes, users } = useDatabase();
  const [showCalculator, setShowCalculator] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('today');
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  // Calculate analytics with proper profit calculation
  const analytics = useMemo((): Analytics => {
    if (!currentUser) return {
      totalIncome: 0,
      totalExpense: 0,
      totalProfit: 0,
      totalCups: 0,
      todayIncome: 0,
      todayExpense: 0,
      todayProfit: 0,
      weeklyData: []
    };

    // Filter transactions based on user role and permissions
    const userTransactions = transactions.filter(t => {
      if (currentUser.role === 'owner') return true;
      if (currentUser.role === 'franchise') return t.createdBy === currentUser.id || t.createdByRole === 'employee';
      return t.createdBy === currentUser.id;
    });

    const now = new Date();
    const today = startOfDay(now);
    
    // Filter by time
    const filteredTransactions = userTransactions.filter(t => {
      const transactionDate = new Date(t.createdAt);
      switch (timeFilter) {
        case 'today':
          return transactionDate >= today;
        case 'thisMonth':
          return transactionDate >= startOfMonth(now);
        case 'lastMonth':
          const lastMonth = subMonths(now, 1);
          return transactionDate >= startOfMonth(lastMonth) && transactionDate < startOfMonth(now);
        case 'thisYear':
          return transactionDate >= startOfYear(now);
        case 'lastYear':
          const lastYear = subYears(now, 1);
          return transactionDate >= startOfYear(lastYear) && transactionDate < startOfYear(now);
        default:
          return true;
      }
    });

    const totalIncome = filteredTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalExpense = filteredTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    const totalCups = filteredTransactions
      .filter(t => t.type === 'income' && t.cups)
      .reduce((sum, t) => sum + (t.cups || 0), 0);

    // Calculate recipe costs for profit calculation
    const recipeCosts = recipes.reduce((acc, recipe) => {
      acc[recipe.menuId] = recipe.totalCost;
      return acc;
    }, {} as Record<string, number>);

    // Calculate total recipe cost based on actual sales
    const totalRecipeCost = filteredTransactions
      .filter(t => t.type === 'income' && t.menuId && recipeCosts[t.menuId])
      .reduce((sum, t) => sum + (recipeCosts[t.menuId] * (t.cups || 1)), 0);

    // Proper profit calculation: Income - Recipe Costs - Expenses
    const totalProfit = totalIncome - totalRecipeCost - totalExpense;

    // Today's data
    const todayTransactions = userTransactions.filter(t => new Date(t.createdAt) >= today);
    const todayIncome = todayTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const todayExpense = todayTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    const todayRecipeCost = todayTransactions
      .filter(t => t.type === 'income' && t.menuId && recipeCosts[t.menuId])
      .reduce((sum, t) => sum + (recipeCosts[t.menuId] * (t.cups || 1)), 0);
    const todayProfit = todayIncome - todayRecipeCost - todayExpense;

    // Weekly data for advanced chart
    const weekStart = startOfWeek(now, { locale: id });
    const weeklyData = Array.from({ length: 7 }, (_, i) => {
      const date = new Date(weekStart);
      date.setDate(date.getDate() + i);
      const dayStart = startOfDay(date);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);

      const dayTransactions = userTransactions.filter(t => {
        const tDate = new Date(t.createdAt);
        return tDate >= dayStart && tDate < dayEnd;
      });

      const dayIncome = dayTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
      const dayExpense = dayTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      const dayRecipeCost = dayTransactions
        .filter(t => t.type === 'income' && t.menuId && recipeCosts[t.menuId])
        .reduce((sum, t) => sum + (recipeCosts[t.menuId] * (t.cups || 1)), 0);
      const dayProfit = dayIncome - dayRecipeCost - dayExpense;

      // Determine trend compared to previous day
      let trend: 'up' | 'down' | 'neutral' = 'neutral';
      if (i > 0) {
        const prevDate = new Date(weekStart);
        prevDate.setDate(prevDate.getDate() + i - 1);
        const prevDayStart = startOfDay(prevDate);
        const prevDayEnd = new Date(prevDayStart);
        prevDayEnd.setDate(prevDayEnd.getDate() + 1);

        const prevDayTransactions = userTransactions.filter(t => {
          const tDate = new Date(t.createdAt);
          return tDate >= prevDayStart && tDate < prevDayEnd;
        });

        const prevDayProfit = prevDayTransactions
          .filter(t => t.type === 'income')
          .reduce((sum, t) => sum + t.amount, 0) -
          prevDayTransactions
          .filter(t => t.type === 'income' && t.menuId && recipeCosts[t.menuId])
          .reduce((sum, t) => sum + (recipeCosts[t.menuId] * (t.cups || 1)), 0) -
          prevDayTransactions
          .filter(t => t.type === 'expense')
          .reduce((sum, t) => sum + t.amount, 0);

        if (dayProfit > prevDayProfit) trend = 'up';
        else if (dayProfit < prevDayProfit) trend = 'down';
      }

      return {
        date: format(date, 'dd/MM', { locale: id }),
        income: dayIncome,
        expense: dayExpense,
        profit: dayProfit,
        trend
      };
    });

    return {
      totalIncome,
      totalExpense,
      totalProfit,
      totalCups,
      todayIncome,
      todayExpense,
      todayProfit,
      weeklyData
    };
  }, [currentUser, transactions, recipes, timeFilter]);

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handleLogout = () => {
    logout();
    onLogout();
  };

  const openModal = (modalName: string) => {
    setActiveModal(modalName);
    setShowMobileMenu(false);
  };

  const closeModal = () => {
    setActiveModal(null);
  };

  if (!currentUser) return null;

  // Employee Dashboard - Simplified view
  if (currentUser.role === 'employee') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              rotate: [0, 180, 360],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full blur-3xl"
          />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
        </div>

        {/* Header */}
        <header className="relative z-10 bg-black/20 backdrop-blur-xl border-b border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-3">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg"
                >
                  <Coffee className="text-white" size={24} />
                </motion.div>
                <div>
                  <h1 className="text-xl font-bold text-white font-poppins">KopiKoe</h1>
                  <p className="text-sm text-gray-300 font-inter">
                    Karyawan: <span className="font-semibold text-amber-400 ml-1">{currentUser.username}</span>
                  </p>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors duration-200 shadow-md"
              >
                <LogOut size={18} />
                <span>Logout</span>
              </motion.button>
            </div>
          </div>
        </header>

        {/* Main Content for Employee */}
        <main className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-4">Panel Karyawan</h2>
            <p className="text-gray-300">Catat transaksi pemasukan untuk bisnis</p>
          </div>

          {/* Transaction Button */}
          <div className="flex justify-center">
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02, y: -5 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => openModal('transactions')}
              className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-8 border border-white/10 hover:shadow-2xl transition-all duration-300 text-center group"
            >
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-16 h-16 rounded-xl bg-gradient-to-r from-green-500 to-green-600 flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow duration-300 mx-auto mb-4"
              >
                <BarChart3 className="text-white" size={32} />
              </motion.div>
              <h3 className="text-xl font-bold text-white mb-2 font-poppins">Catat Pemasukan</h3>
              <p className="text-gray-300 font-inter">Tambahkan transaksi penjualan</p>
            </motion.button>
          </div>
        </main>

        {/* Transaction Modal */}
        <AnimatePresence>
          {activeModal === 'transactions' && (
            <TransactionManagement onClose={closeModal} />
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Full Dashboard for Owner and Franchise
  const statsCards = [
    {
      title: 'Total Pendapatan',
      value: formatCurrency(analytics.totalIncome),
      icon: DollarSign,
      color: 'from-emerald-500 to-emerald-600',
      textColor: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-200'
    },
    {
      title: 'Total Pengeluaran',
      value: formatCurrency(analytics.totalExpense),
      icon: ShoppingCart,
      color: 'from-red-500 to-red-600',
      textColor: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    },
    {
      title: 'Keuntungan Bersih',
      value: formatCurrency(analytics.totalProfit),
      icon: analytics.totalProfit >= 0 ? TrendingUp : TrendingDown,
      color: analytics.totalProfit >= 0 ? 'from-blue-500 to-blue-600' : 'from-orange-500 to-orange-600',
      textColor: analytics.totalProfit >= 0 ? 'text-blue-600' : 'text-orange-600',
      bgColor: analytics.totalProfit >= 0 ? 'bg-blue-50' : 'bg-orange-50',
      borderColor: analytics.totalProfit >= 0 ? 'border-blue-200' : 'border-orange-200'
    },
    {
      title: 'Total Cup Terjual',
      value: analytics.totalCups.toLocaleString('id-ID'),
      icon: Coffee,
      color: 'from-amber-500 to-amber-600',
      textColor: 'text-amber-600',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200'
    }
  ];

  const menuItems = [
    { 
      icon: Package, 
      label: 'Kelola Menu', 
      action: () => openModal('menu'),
      description: 'Tambah, edit, dan hapus menu',
      color: 'from-purple-500 to-purple-600'
    },
    { 
      icon: ChefHat, 
      label: 'Kelola Bahan', 
      action: () => openModal('materials'),
      description: 'Manajemen bahan baku',
      color: 'from-orange-500 to-orange-600'
    },
    { 
      icon: Receipt, 
      label: 'Kelola Resep', 
      action: () => openModal('recipes'),
      description: 'Buat dan kelola resep',
      color: 'from-green-500 to-green-600'
    },
    { 
      icon: BarChart3, 
      label: 'Transaksi', 
      action: () => openModal('transactions'),
      description: 'Catat pemasukan & pengeluaran',
      color: 'from-blue-500 to-blue-600'
    },
    { 
      icon: Eye, 
      label: 'Lihat Data', 
      action: () => openModal('data'),
      description: 'Tabel data lengkap',
      color: 'from-teal-500 to-teal-600'
    }
  ];

  if (currentUser.role === 'owner') {
    menuItems.push({
      icon: Users,
      label: 'Kelola Akun',
      action: () => openModal('accounts'),
      description: 'Manajemen user & akses',
      color: 'from-indigo-500 to-indigo-600'
    });
  }

  // Floating particles for background animation
  const particles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 5,
    duration: 10 + Math.random() * 20,
    size: Math.random() * 4 + 1,
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Orbs */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-10 right-10 w-80 h-80 bg-gradient-to-r from-blue-500/30 to-cyan-500/30 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            x: [0, 100, 0],
            y: [0, -50, 0],
            opacity: [0.4, 0.7, 0.4],
          }}
          transition={{
            duration: 30,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 rounded-full blur-2xl"
        />

        {/* Floating Particles */}
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute bg-white/10 rounded-full"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
            }}
            animate={{
              y: [-20, -100, -20],
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: particle.duration,
              repeat: Infinity,
              delay: particle.delay,
              ease: "easeInOut"
            }}
          />
        ))}

        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Header */}
      <header className="relative z-10 bg-black/20 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo & Title */}
            <div className="flex items-center space-x-3">
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg"
              >
                <Coffee className="text-white" size={24} />
              </motion.div>
              <div>
                <h1 className="text-xl font-bold text-white font-poppins">KopiKoe</h1>
                <p className="text-sm text-gray-300 font-inter">
                  Masuk sebagai: 
                  <span className="font-semibold text-amber-400 ml-1">
                    {currentUser.username}
                    {currentUser.role === 'owner' && <Crown className="inline ml-1" size={14} />}
                    {currentUser.role === 'franchise' && <Building2 className="inline ml-1" size={14} />}
                    {currentUser.role === 'employee' && <User className="inline ml-1" size={14} />}
                  </span>
                </p>
              </div>
            </div>

            {/* Desktop Actions */}
            <div className="hidden md:flex items-center space-x-4">
              {/* Time Filter */}
              <select
                value={timeFilter}
                onChange={(e) => setTimeFilter(e.target.value as TimeFilter)}
                className="px-3 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              >
                <option value="today" className="text-gray-900">Hari Ini</option>
                <option value="thisMonth" className="text-gray-900">Bulan Ini</option>
                <option value="lastMonth" className="text-gray-900">Bulan Lalu</option>
                <option value="thisYear" className="text-gray-900">Tahun Ini</option>
                <option value="lastYear" className="text-gray-900">Tahun Lalu</option>
              </select>

              {/* Export Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={exportToExcel}
                className="flex items-center space-x-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition-colors duration-200 shadow-md"
              >
                <Download size={18} />
                <span>Export</span>
              </motion.button>

              {/* Logout Button */}
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors duration-200 shadow-md"
              >
                <LogOut size={18} />
                <span>Logout</span>
              </motion.button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="md:hidden p-2 rounded-lg text-gray-300 hover:text-white hover:bg-white/10 transition-colors duration-200"
            >
              {showMobileMenu ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {showMobileMenu && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-black/30 backdrop-blur-xl border-t border-white/10"
            >
              <div className="px-4 py-3 space-y-3">
                <select
                  value={timeFilter}
                  onChange={(e) => setTimeFilter(e.target.value as TimeFilter)}
                  className="w-full px-3 py-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  <option value="today" className="text-gray-900">Hari Ini</option>
                  <option value="thisMonth" className="text-gray-900">Bulan Ini</option>
                  <option value="lastMonth" className="text-gray-900">Bulan Lalu</option>
                  <option value="thisYear" className="text-gray-900">Tahun Ini</option>
                  <option value="lastYear" className="text-gray-900">Tahun Lalu</option>
                </select>
                
                <div className="flex space-x-2">
                  <button
                    onClick={exportToExcel}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium"
                  >
                    <Download size={18} />
                    <span>Export</span>
                  </button>
                  
                  <button
                    onClick={handleLogout}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg font-medium"
                  >
                    <LogOut size={18} />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((card, index) => (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
              className={`bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border ${card.borderColor} border-opacity-20 hover:shadow-2xl transition-all duration-300`}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-300 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold text-white mb-2">{card.value}</p>
                </div>
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className={`w-12 h-12 rounded-xl ${card.bgColor} bg-opacity-20 flex items-center justify-center`}
                >
                  <card.icon className={card.textColor} size={24} />
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Advanced Trading-Style Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 mb-8 border border-white/10"
        >
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-white mb-0 font-poppins flex items-center">
              <Activity className="mr-2 text-amber-400" size={24} />
              Grafik Keuntungan Mingguan
            </h3>
            <div className="flex items-center space-x-2 text-sm text-gray-300">
              <Zap className="text-emerald-400" size={16} />
              <span>Real-time</span>
            </div>
          </div>
          
          <div className="relative">
            {/* Chart Container */}
            <div className="flex justify-between items-end h-64 space-x-1 bg-black/20 rounded-xl p-4 border border-white/5">
              {analytics.weeklyData.map((day, index) => {
                const maxProfit = Math.max(...analytics.weeklyData.map(d => Math.abs(d.profit)), 1);
                const height = Math.abs(day.profit) / maxProfit * 100;
                const isPositive = day.profit >= 0;
                
                return (
                  <div key={day.date} className="flex-1 flex flex-col items-center">
                    {/* Price Label */}
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="mb-2 text-xs text-gray-300 font-mono"
                    >
                      {formatCurrency(day.profit).replace('Rp', '')}
                    </motion.div>
                    
                    {/* Candlestick-style Bar */}
                    <div className="relative flex-1 w-full flex flex-col justify-end">
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${height}%` }}
                        transition={{ delay: index * 0.1, duration: 0.8, ease: "easeOut" }}
                        className={`w-full rounded-t-lg relative group cursor-pointer ${
                          isPositive 
                            ? 'bg-gradient-to-t from-emerald-500 to-emerald-400' 
                            : 'bg-gradient-to-t from-red-500 to-red-400'
                        } min-h-[4px] shadow-lg`}
                        style={{
                          boxShadow: isPositive 
                            ? '0 0 20px rgba(16, 185, 129, 0.3)' 
                            : '0 0 20px rgba(239, 68, 68, 0.3)'
                        }}
                      >
                        {/* Trend Indicator */}
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: index * 0.1 + 0.5 }}
                          className="absolute -top-6 left-1/2 transform -translate-x-1/2"
                        >
                          {day.trend === 'up' && (
                            <TrendingUp className="text-emerald-400" size={16} />
                          )}
                          {day.trend === 'down' && (
                            <TrendingDown className="text-red-400" size={16} />
                          )}
                        </motion.div>
                        
                        {/* Hover Tooltip */}
                        <div className="absolute -top-16 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap z-10 border border-gray-700">
                          <div className="text-center">
                            <div className="font-semibold">{day.date}</div>
                            <div className={isPositive ? 'text-emerald-400' : 'text-red-400'}>
                              {formatCurrency(day.profit)}
                            </div>
                            <div className="text-gray-400 text-xs">
                              Pendapatan: {formatCurrency(day.income)}
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    </div>
                    
                    {/* Date Label */}
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: index * 0.1 + 0.3 }}
                      className="mt-2 text-xs font-medium text-gray-400"
                    >
                      {day.date}
                    </motion.div>
                  </div>
                );
              })}
            </div>
            
            {/* Chart Legend */}
            <div className="flex justify-center mt-4 space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                <span className="text-gray-300">Profit</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span className="text-gray-300">Loss</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature Menu */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.map((item, index) => (
            <motion.button
              key={item.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
              whileTap={{ scale: 0.98 }}
              onClick={item.action}
              className="bg-white/10 backdrop-blur-xl rounded-2xl shadow-xl p-6 border border-white/10 hover:shadow-2xl transition-all duration-300 text-left group"
            >
              <div className="flex items-center space-x-4">
                <motion.div 
                  whileHover={{ scale: 1.1, rotate: 360 }}
                  transition={{ duration: 0.5 }}
                  className={`w-12 h-12 rounded-xl bg-gradient-to-r ${item.color} flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow duration-300`}
                >
                  <item.icon className="text-white" size={24} />
                </motion.div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white mb-1 font-poppins">{item.label}</h3>
                  <p className="text-sm text-gray-300 font-inter">{item.description}</p>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </main>

      {/* Floating Calculator Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setShowCalculator(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-full shadow-lg hover:shadow-xl transition-shadow duration-300 flex items-center justify-center z-40"
      >
        <Calculator size={24} />
      </motion.button>

      {/* Floating Calculator */}
      <AnimatePresence>
        {showCalculator && (
          <FloatingCalculator onClose={() => setShowCalculator(false)} />
        )}
      </AnimatePresence>

      {/* Modals */}
      <AnimatePresence>
        {activeModal === 'menu' && (
          <MenuManagement onClose={closeModal} />
        )}
        {activeModal === 'materials' && (
          <MaterialManagement onClose={closeModal} />
        )}
        {activeModal === 'recipes' && (
          <RecipeManagement onClose={closeModal} />
        )}
        {activeModal === 'transactions' && (
          <TransactionManagement onClose={closeModal} />
        )}
        {activeModal === 'accounts' && (
          <AccountManagement onClose={closeModal} />
        )}
        {activeModal === 'data' && (
          <DataViewer onClose={closeModal} />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Dashboard;