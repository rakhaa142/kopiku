import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Coffee, 
  Star, 
  Phone, 
  MapPin, 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  Send,
  Camera,
  Heart,
  Award,
  Users,
  Sparkles,
  LogIn,
  Navigation,
  CreditCard,
  Instagram,
  Facebook,
  Twitter,
  Mail,
  Shield,
  Zap,
  TrendingUp
} from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import ReviewManagement from './ReviewManagement';

interface PortfolioProps {
  onLoginClick: () => void;
}

const Portfolio: React.FC<PortfolioProps> = ({ onLoginClick }) => {
  const { reviews, addReview, currentUser } = useDatabase();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [backgroundIndex, setBackgroundIndex] = useState(0);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [showReviewManagement, setShowReviewManagement] = useState(false);
  const [reviewForm, setReviewForm] = useState({
    name: '',
    rating: 5,
    comment: '',
    image: null as File | null
  });

  // Background gradient transitions
  const backgrounds = [
    'from-amber-900 via-orange-900 to-red-900',
    'from-orange-900 via-amber-900 to-yellow-900',
    'from-red-900 via-orange-900 to-amber-900',
    'from-yellow-900 via-amber-900 to-orange-900',
    'from-amber-800 via-orange-800 to-red-800',
    'from-orange-800 via-red-800 to-pink-800'
  ];

  // Auto-change background every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setBackgroundIndex((prev) => (prev + 1) % backgrounds.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const menuItems = [
    {
      id: 1,
      name: 'Matcha Coffee',
      price: 10000,
      description: 'Perpaduan sempurna antara matcha premium dan espresso berkualitas tinggi',
      image: 'https://images.pexels.com/photos/5946963/pexels-photo-5946963.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Signature',
      ingredients: ['Matcha Premium', 'Espresso', 'Steamed Milk', 'Vanilla Syrup']
    },
    {
      id: 2,
      name: 'Creamy Latte',
      price: 10000,
      description: 'Latte klasik dengan foam susu yang lembut dan creamy',
      image: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Classic',
      ingredients: ['Espresso', 'Steamed Milk', 'Milk Foam', 'Cinnamon']
    },
    {
      id: 3,
      name: 'Brown Sugar Coffee',
      price: 10000,
      description: 'Kopi dengan sentuhan brown sugar yang memberikan rasa manis alami',
      image: 'https://images.pexels.com/photos/4109743/pexels-photo-4109743.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Sweet',
      ingredients: ['Espresso', 'Brown Sugar', 'Steamed Milk', 'Caramel Drizzle']
    },
    {
      id: 4,
      name: 'Americano',
      price: 8000,
      description: 'Kopi hitam klasik untuk pecinta kopi sejati',
      image: 'https://images.pexels.com/photos/1695052/pexels-photo-1695052.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Classic',
      ingredients: ['Double Espresso', 'Hot Water', 'Optional Sugar']
    },
    {
      id: 5,
      name: 'Caramel Macchiato',
      price: 12000,
      description: 'Espresso dengan vanilla syrup, steamed milk, dan caramel drizzle',
      image: 'https://images.pexels.com/photos/4109999/pexels-photo-4109999.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Premium',
      ingredients: ['Espresso', 'Vanilla Syrup', 'Steamed Milk', 'Caramel Sauce']
    },
    {
      id: 6,
      name: 'Cappuccino',
      price: 9000,
      description: 'Perpaduan sempurna espresso, steamed milk, dan thick foam',
      image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=800',
      category: 'Classic',
      ingredients: ['Espresso', 'Steamed Milk', 'Milk Foam', 'Cocoa Powder']
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % menuItems.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + menuItems.length) % menuItems.length);
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    addReview({
      customerName: reviewForm.name,
      rating: reviewForm.rating,
      comment: reviewForm.comment,
      image: reviewForm.image ? URL.createObjectURL(reviewForm.image) : undefined,
      isApproved: false
    });

    setReviewForm({ name: '', rating: 5, comment: '', image: null });
    setShowReviewForm(false);
  };

  const approvedReviews = reviews.filter(review => review.isApproved);
  const averageRating = approvedReviews.length > 0 
    ? approvedReviews.reduce((sum, review) => sum + review.rating, 0) / approvedReviews.length 
    : 5;

  // Floating particles for background animation
  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    delay: Math.random() * 5,
    duration: 10 + Math.random() * 20,
    size: Math.random() * 4 + 1,
  }));

  return (
    <div className={`min-h-screen bg-gradient-to-br ${backgrounds[backgroundIndex]} relative overflow-hidden transition-all duration-1000`}>
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Orbs */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-r from-amber-500/20 to-orange-500/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-10 right-10 w-80 h-80 bg-gradient-to-r from-yellow-500/20 to-red-500/20 rounded-full blur-3xl"
        />

        {/* Floating Particles */}
        {particles.map((particle) => (
          <motion.div
            key={particle.id}
            className="absolute bg-amber-400/10 rounded-full"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
            }}
            animate={{
              y: [-20, -100, -20],
              opacity: [0, 0.6, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: particle.duration,
              repeat: Infinity,
              delay: particle.delay,
              ease: "easeInOut"
            }}
          />
        ))}

        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Header */}
      <header className="relative z-10 bg-black/20 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center space-x-3"
            >
              <motion.div 
                whileHover={{ scale: 1.1, rotate: 360 }}
                transition={{ duration: 0.5 }}
                className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg"
              >
                <Coffee className="text-white" size={24} />
              </motion.div>
              <div>
                <h1 className="text-xl font-bold text-white font-poppins">KopiKoe</h1>
                <p className="text-xs text-amber-300 font-inter">Premium Coffee Experience</p>
              </div>
            </motion.div>

            {/* Navigation & Login */}
            <div className="flex items-center space-x-6">
              <nav className="hidden md:flex items-center space-x-6">
                <a href="#menu" className="text-white/80 hover:text-white transition-colors duration-200 font-medium">Menu</a>
                <a href="#reviews" className="text-white/80 hover:text-white transition-colors duration-200 font-medium">Reviews</a>
                <a href="#contact" className="text-white/80 hover:text-white transition-colors duration-200 font-medium">Contact</a>
              </nav>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onLoginClick}
                className="flex items-center space-x-2 px-4 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors duration-200 shadow-md"
              >
                <LogIn size={18} />
                <span>Login</span>
              </motion.button>

              {currentUser?.role === 'owner' && (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowReviewManagement(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors duration-200 shadow-md"
                >
                  <Shield size={18} />
                  <span>Manage</span>
                </motion.button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 pt-20 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1 
              className="text-5xl md:text-7xl font-bold text-white mb-6 font-poppins"
              animate={{
                textShadow: [
                  '0 0 20px rgba(251, 191, 36, 0.5)',
                  '0 0 40px rgba(251, 191, 36, 0.8)',
                  '0 0 20px rgba(251, 191, 36, 0.5)'
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Welcome to <span className="bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent">KopiKoe</span>
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl text-amber-100 mb-8 max-w-3xl mx-auto font-inter"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              Nikmati pengalaman kopi premium dengan cita rasa autentik yang memanjakan lidah Anda
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            >
              <motion.a
                href="#menu"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Lihat Menu
              </motion.a>
              
              <motion.a
                href="tel:+6285169856141"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white/10 backdrop-blur-md text-white rounded-xl font-semibold text-lg border border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <Phone className="inline mr-2" size={20} />
                Hubungi Kami
              </motion.a>
            </motion.div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20"
          >
            {[
              { icon: Users, label: 'Happy Customers', value: '1000+' },
              { icon: Coffee, label: 'Coffee Varieties', value: '6+' },
              { icon: Star, label: 'Average Rating', value: averageRating.toFixed(1) },
              { icon: Award, label: 'Years Experience', value: '5+' }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1 + index * 0.1 }}
                className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20"
              >
                <stat.icon className="text-amber-400 mx-auto mb-3" size={32} />
                <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-amber-200 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" className="relative z-10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-poppins">
              Menu <span className="bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent">Spesial</span>
            </h2>
            <p className="text-xl text-amber-100 max-w-2xl mx-auto font-inter">
              Koleksi kopi premium yang dibuat dengan bahan berkualitas tinggi dan resep rahasia kami
            </p>
          </motion.div>

          {/* Product Carousel */}
          <div className="relative">
            <div className="overflow-hidden rounded-3xl">
              <motion.div
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentSlide * 100}%)` }}
              >
                {menuItems.map((item, index) => (
                  <div key={item.id} className="w-full flex-shrink-0">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center p-8 bg-white/10 backdrop-blur-xl border border-white/20">
                      <motion.div
                        initial={{ opacity: 0, x: -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.2 }}
                      >
                        <div className="relative">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                          />
                          <div className="absolute top-4 left-4 bg-amber-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                            {item.category}
                          </div>
                        </div>
                      </motion.div>

                      <motion.div
                        initial={{ opacity: 0, x: 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.4 }}
                        className="space-y-6"
                      >
                        <div>
                          <h3 className="text-3xl font-bold text-white mb-3 font-poppins">{item.name}</h3>
                          <p className="text-amber-100 text-lg leading-relaxed font-inter">{item.description}</p>
                        </div>

                        <div className="space-y-4">
                          <div className="text-3xl font-bold text-amber-400">
                            {formatCurrency(item.price)}
                          </div>
                          
                          <div>
                            <h4 className="text-white font-semibold mb-2">Ingredients:</h4>
                            <div className="flex flex-wrap gap-2">
                              {item.ingredients.map((ingredient, idx) => (
                                <span
                                  key={idx}
                                  className="px-3 py-1 bg-amber-600/20 text-amber-200 rounded-full text-sm border border-amber-600/30"
                                >
                                  {ingredient}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>

                        <motion.a
                          href="tel:+6285169856141"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
                        >
                          <Phone size={20} />
                          <span>Pesan Sekarang</span>
                        </motion.a>
                      </motion.div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-all duration-200"
            >
              <ChevronLeft size={24} />
            </button>
            
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/30 transition-all duration-200"
            >
              <ChevronRight size={24} />
            </button>

            {/* Dots Indicator */}
            <div className="flex justify-center space-x-2 mt-8">
              {menuItems.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-200 ${
                    index === currentSlide ? 'bg-amber-400' : 'bg-white/30'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="relative z-10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-poppins">
              Customer <span className="bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent">Reviews</span>
            </h2>
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${i < Math.floor(averageRating) ? 'text-amber-400 fill-current' : 'text-gray-400'}`}
                  />
                ))}
              </div>
              <span className="text-white text-lg font-semibold">
                {averageRating.toFixed(1)} ({approvedReviews.length} reviews)
              </span>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowReviewForm(true)}
              className="px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
            >
              <Star className="inline mr-2" size={20} />
              Tulis Review
            </motion.button>
          </motion.div>

          {/* Reviews Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {approvedReviews.slice(0, 6).map((review, index) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold">
                    {review.customerName.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="text-white font-semibold">{review.customerName}</h4>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${i < review.rating ? 'text-amber-400 fill-current' : 'text-gray-400'}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                
                <p className="text-amber-100 mb-4">{review.comment}</p>
                
                {review.image && (
                  <img
                    src={review.image}
                    alt="Review"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                )}
                
                <div className="text-xs text-amber-300 mt-3">
                  {new Date(review.createdAt).toLocaleDateString('id-ID')}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Section */}
      <section className="relative z-10 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20"
          >
            <h2 className="text-3xl font-bold text-white mb-6 font-poppins">
              <CreditCard className="inline mr-3" size={32} />
              Pembayaran Mudah
            </h2>
            
            <p className="text-amber-100 mb-8 text-lg">
              Scan QR Code di bawah untuk melakukan pembayaran langsung
            </p>
            
            <div className="max-w-md mx-auto">
              <img
                src="/WhatsApp Image 2025-05-24 at 16.03.51_c03db9ab.jpg"
                alt="QR Code Pembayaran KopiKoe"
                className="w-full rounded-2xl shadow-2xl border-4 border-white/20"
              />
            </div>
            
            <div className="mt-6 text-amber-200">
              <p className="font-semibold">KOPIKOE - QRIS Payment</p>
              <p className="text-sm">Scan untuk pembayaran instan</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Contact & Location Section */}
      <section id="contact" className="relative z-10 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 font-poppins">
              Hubungi <span className="bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent">Kami</span>
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-2xl font-bold text-white mb-6">Informasi Kontak</h3>
                
                <div className="space-y-4">
                  <motion.a
                    href="tel:+6285169856141"
                    whileHover={{ scale: 1.02 }}
                    className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl hover:bg-white/20 transition-all duration-200"
                  >
                    <Phone className="text-amber-400" size={24} />
                    <div>
                      <div className="text-white font-semibold">Telepon</div>
                      <div className="text-amber-200">+62 851-6985-6141</div>
                    </div>
                  </motion.a>
                  
                  <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl">
                    <MapPin className="text-amber-400" size={24} />
                    <div>
                      <div className="text-white font-semibold">Lokasi</div>
                      <div className="text-amber-200">Rumah Sakit Ummi, Kota Bengkulu</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-white/10 rounded-xl">
                    <Clock className="text-amber-400" size={24} />
                    <div>
                      <div className="text-white font-semibold">Jam Buka</div>
                      <div className="text-amber-200">07:00 - 22:00 WIB</div>
                    </div>
                  </div>
                </div>

                <motion.a
                  href="https://maps.google.com/?q=Rumah+Sakit+Ummi+Bengkulu"
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="inline-flex items-center space-x-2 mt-6 px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
                >
                  <Navigation size={20} />
                  <span>Lihat di Maps</span>
                </motion.a>
              </div>

              {/* Social Media */}
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                <h3 className="text-xl font-bold text-white mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  {[
                    { icon: Instagram, color: 'from-pink-500 to-purple-600' },
                    { icon: Facebook, color: 'from-blue-500 to-blue-700' },
                    { icon: Twitter, color: 'from-blue-400 to-blue-600' },
                    { icon: Mail, color: 'from-red-500 to-red-700' }
                  ].map((social, index) => (
                    <motion.button
                      key={index}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className={`w-12 h-12 bg-gradient-to-r ${social.color} rounded-xl flex items-center justify-center text-white shadow-lg hover:shadow-xl transition-all duration-300`}
                    >
                      <social.icon size={20} />
                    </motion.button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Map */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20"
            >
              <h3 className="text-2xl font-bold text-white mb-6">Lokasi Kami</h3>
              <div className="aspect-video rounded-xl overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3981.2345678901234!2d102.2345678!3d-3.7890123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sRumah%20Sakit%20Ummi%20Bengkulu!5e0!3m2!1sen!2sid!4v1234567890123"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="rounded-xl"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 bg-black/30 backdrop-blur-xl border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center">
                  <Coffee className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">KopiKoe</h3>
                  <p className="text-amber-300 text-sm">Premium Coffee Experience</p>
                </div>
              </div>
              <p className="text-amber-100 text-sm">
                Menyajikan kopi berkualitas tinggi dengan cita rasa autentik untuk pengalaman yang tak terlupakan.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2">
                <a href="#menu" className="block text-amber-200 hover:text-white transition-colors duration-200">Menu</a>
                <a href="#reviews" className="block text-amber-200 hover:text-white transition-colors duration-200">Reviews</a>
                <a href="#contact" className="block text-amber-200 hover:text-white transition-colors duration-200">Contact</a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Contact Info</h4>
              <div className="space-y-2 text-amber-200 text-sm">
                <p>+62 851-6985-6141</p>
                <p>Rumah Sakit Ummi, Kota Bengkulu</p>
                <p>07:00 - 22:00 WIB</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-white/10 mt-8 pt-8 text-center">
            <p className="text-amber-200 text-sm">
              © 2024 KopiKoe. All rights reserved. Made with ❤️ for coffee lovers.
            </p>
          </div>
        </div>
      </footer>

      {/* Review Form Modal */}
      <AnimatePresence>
        {showReviewForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowReviewForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Tulis Review</h3>
              
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Nama</label>
                  <input
                    type="text"
                    value={reviewForm.name}
                    onChange={(e) => setReviewForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewForm(prev => ({ ...prev, rating: star }))}
                        className={`w-8 h-8 ${star <= reviewForm.rating ? 'text-amber-400' : 'text-gray-300'}`}
                      >
                        <Star className="w-full h-full fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Komentar</label>
                  <textarea
                    value={reviewForm.comment}
                    onChange={(e) => setReviewForm(prev => ({ ...prev, comment: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                    rows={4}
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Foto (Opsional)</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setReviewForm(prev => ({ ...prev, image: e.target.files?.[0] || null }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
                
                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowReviewForm(false)}
                    className="flex-1 px-4 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300"
                  >
                    <Send className="inline mr-2" size={16} />
                    Kirim
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Review Management Modal */}
      <AnimatePresence>
        {showReviewManagement && (
          <ReviewManagement onClose={() => setShowReviewManagement(false)} />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Portfolio;