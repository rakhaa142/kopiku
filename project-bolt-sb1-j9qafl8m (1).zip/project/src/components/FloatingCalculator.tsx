import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Calculator } from 'lucide-react';

interface FloatingCalculatorProps {
  onClose: () => void;
}

const FloatingCalculator: React.FC<FloatingCalculatorProps> = ({ onClose }) => {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(String(num));
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? String(num) : display + num);
    }
  };

  const inputDot = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      let result: number;

      switch (operation) {
        case '+':
          result = currentValue + inputValue;
          break;
        case '-':
          result = currentValue - inputValue;
          break;
        case '*':
          result = currentValue * inputValue;
          break;
        case '/':
          result = currentValue / inputValue;
          break;
        case '%':
          result = currentValue % inputValue;
          break;
        default:
          return;
      }

      setPreviousValue(result);
      setDisplay(String(result));
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  };

  const calculate = () => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      performOperation('=');
      setOperation(null);
      setPreviousValue(null);
      setWaitingForOperand(true);
    }
  };

  const formatDisplay = (value: string): string => {
    const num = parseFloat(value);
    if (isNaN(num)) return value;
    
    // Format dengan titik sebagai pemisah ribuan
    return new Intl.NumberFormat('id-ID', {
      maximumFractionDigits: 8,
      useGrouping: true
    }).format(num);
  };

  const buttons = [
    ['C', '±', '%', '/'],
    ['7', '8', '9', '*'],
    ['4', '5', '6', '-'],
    ['1', '2', '3', '+'],
    ['0', '.', '=']
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="bg-white rounded-3xl shadow-2xl p-6 w-full max-w-sm max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-coffee-600 to-coffee-700 rounded-xl flex items-center justify-center">
              <Calculator className="text-white" size={16} />
            </div>
            <h3 className="text-lg font-bold text-gray-900 font-poppins">Kalkulator</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors duration-200"
          >
            <X size={16} className="text-gray-600" />
          </button>
        </div>

        {/* Display */}
        <div className="bg-gray-50 rounded-2xl p-4 mb-6">
          <div className="text-right">
            <div className="text-3xl font-bold text-gray-900 min-h-[40px] flex items-center justify-end font-mono">
              {formatDisplay(display)}
            </div>
            {operation && previousValue !== null && (
              <div className="text-sm text-gray-500 mt-1">
                {formatDisplay(String(previousValue))} {operation}
              </div>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div className="space-y-3">
          {buttons.map((row, rowIndex) => (
            <div key={rowIndex} className="flex space-x-3">
              {row.map((btn) => {
                const isOperation = ['/', '*', '-', '+', '='].includes(btn);
                const isSpecial = ['C', '±', '%'].includes(btn);
                const isZero = btn === '0';
                
                return (
                  <motion.button
                    key={btn}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      if (btn === 'C') {
                        clear();
                      } else if (btn === '=') {
                        calculate();
                      } else if (btn === '.') {
                        inputDot();
                      } else if (btn === '±') {
                        setDisplay(String(parseFloat(display) * -1));
                      } else if (['+', '-', '*', '/', '%'].includes(btn)) {
                        performOperation(btn);
                      } else {
                        inputNumber(btn);
                      }
                    }}
                    className={`
                      h-12 rounded-xl font-semibold text-lg transition-all duration-200 shadow-sm hover:shadow-md
                      ${isZero ? 'flex-1' : 'flex-1'}
                      ${isOperation 
                        ? 'bg-gradient-to-r from-coffee-600 to-coffee-700 text-white hover:from-coffee-700 hover:to-coffee-800' 
                        : isSpecial
                        ? 'bg-gradient-to-r from-gray-400 to-gray-500 text-white hover:from-gray-500 hover:to-gray-600'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                      }
                      ${operation === btn ? 'ring-2 ring-coffee-300' : ''}
                    `}
                  >
                    {btn}
                  </motion.button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Info */}
        <div className="mt-6 p-3 bg-coffee-50 rounded-xl">
          <p className="text-sm text-coffee-700 text-center font-medium">
            Kalkulator dengan format angka Indonesia
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default FloatingCalculator;