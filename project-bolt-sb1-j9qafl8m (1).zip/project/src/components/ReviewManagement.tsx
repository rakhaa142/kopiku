import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Star, Check, Trash2, Eye, EyeOff, Shield, AlertTriangle } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';

interface ReviewManagementProps {
  onClose: () => void;
}

const ReviewManagement: React.FC<ReviewManagementProps> = ({ onClose }) => {
  const { reviews, approveReview, deleteReview, currentUser } = useDatabase();
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved'>('all');

  // Only owner can access this component
  if (currentUser?.role !== 'owner') {
    return null;
  }

  const filteredReviews = reviews.filter(review => {
    switch (filter) {
      case 'pending':
        return !review.isApproved;
      case 'approved':
        return review.isApproved;
      default:
        return true;
    }
  });

  const handleApprove = (reviewId: string) => {
    approveReview(reviewId);
  };

  const handleDelete = (review: any) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus review dari ${review.customerName}?`)) {
      deleteReview(review.id);
    }
  };

  const pendingCount = reviews.filter(r => !r.isApproved).length;
  const approvedCount = reviews.filter(r => r.isApproved).length;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Shield className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Kelola Review</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Filter Tabs */}
          <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
            {[
              { key: 'all', label: 'Semua', count: reviews.length },
              { key: 'pending', label: 'Menunggu', count: pendingCount },
              { key: 'approved', label: 'Disetujui', count: approvedCount }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key as any)}
                className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-semibold transition-all duration-200 ${
                  filter === tab.key
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <span>{tab.label}</span>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  filter === tab.key ? 'bg-white/20' : 'bg-gray-200'
                }`}>
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
              <div className="flex items-center space-x-2 mb-2">
                <Eye className="text-blue-600" size={20} />
                <h4 className="font-semibold text-blue-800">Total Review</h4>
              </div>
              <p className="text-2xl font-bold text-blue-600">{reviews.length}</p>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="text-yellow-600" size={20} />
                <h4 className="font-semibold text-yellow-800">Menunggu Persetujuan</h4>
              </div>
              <p className="text-2xl font-bold text-yellow-600">{pendingCount}</p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-xl border border-green-200">
              <div className="flex items-center space-x-2 mb-2">
                <Check className="text-green-600" size={20} />
                <h4 className="font-semibold text-green-800">Disetujui</h4>
              </div>
              <p className="text-2xl font-bold text-green-600">{approvedCount}</p>
            </div>
          </div>

          {/* Reviews List */}
          <div className="space-y-4">
            {filteredReviews.length === 0 ? (
              <div className="text-center py-12">
                <Shield className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">
                  {filter === 'all' ? 'Belum ada review' : 
                   filter === 'pending' ? 'Tidak ada review yang menunggu persetujuan' :
                   'Tidak ada review yang disetujui'}
                </p>
              </div>
            ) : (
              filteredReviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`bg-white border rounded-2xl p-6 hover:shadow-lg transition-shadow duration-200 ${
                    review.isApproved ? 'border-green-200 bg-green-50/30' : 'border-yellow-200 bg-yellow-50/30'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                          {review.customerName.charAt(0).toUpperCase()}
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">{review.customerName}</h3>
                          <div className="flex items-center space-x-2">
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`w-4 h-4 ${i < review.rating ? 'text-amber-400 fill-current' : 'text-gray-300'}`}
                                />
                              ))}
                            </div>
                            <span className="text-sm text-gray-500">
                              {new Date(review.createdAt).toLocaleDateString('id-ID')}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {review.isApproved ? (
                            <span className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full font-medium">
                              <Check size={14} />
                              <span>Disetujui</span>
                            </span>
                          ) : (
                            <span className="flex items-center space-x-1 px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full font-medium">
                              <AlertTriangle size={14} />
                              <span>Menunggu</span>
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-4 leading-relaxed">{review.comment}</p>
                      
                      {review.image && (
                        <div className="mb-4">
                          <img
                            src={review.image}
                            alt="Review"
                            className="w-32 h-32 object-cover rounded-lg border border-gray-200"
                          />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      {!review.isApproved && (
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleApprove(review.id)}
                          className="p-2 bg-green-100 text-green-600 rounded-xl hover:bg-green-200 transition-colors duration-200"
                          title="Setujui review"
                        >
                          <Check size={16} />
                        </motion.button>
                      )}
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleDelete(review)}
                        className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors duration-200"
                        title="Hapus review"
                      >
                        <Trash2 size={16} />
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {/* Moderation Guidelines */}
          <div className="mt-8 p-6 bg-purple-50 rounded-2xl border border-purple-200">
            <h3 className="text-lg font-semibold text-purple-800 mb-4">Panduan Moderasi Review</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-purple-700">
              <div>
                <h4 className="font-semibold mb-2">✅ Review yang Disetujui:</h4>
                <ul className="space-y-1">
                  <li>• Komentar yang konstruktif dan relevan</li>
                  <li>• Pengalaman nyata dengan produk</li>
                  <li>• Bahasa yang sopan dan pantas</li>
                  <li>• Foto yang sesuai dengan produk</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">❌ Review yang Ditolak:</h4>
                <ul className="space-y-1">
                  <li>• Konten yang tidak pantas atau vulgar</li>
                  <li>• Spam atau review palsu</li>
                  <li>• Bahasa yang kasar atau menyinggung</li>
                  <li>• Foto yang tidak relevan atau tidak pantas</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default ReviewManagement;