import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, Edit3, Trash2, Search, ChefHat, Calculator } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { Recipe, RecipeMaterial } from '../types';

interface RecipeManagementProps {
  onClose: () => void;
}

const RecipeManagement: React.FC<RecipeManagementProps> = ({ onClose }) => {
  const { recipes, menus, materials, addRecipe, updateRecipe, deleteRecipe, currentUser } = useDatabase();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [formData, setFormData] = useState({
    menuId: '',
    materials: [] as { materialId: string; weight: string }[]
  });

  // Filter data based on user permissions  
  const userMenus = menus.filter(menu => {
    if (currentUser?.role === 'owner') return true;
    return menu.createdBy === currentUser?.id;
  });

  const userMaterials = materials.filter(material => {
    if (currentUser?.role === 'owner') return true;
    return material.createdBy === currentUser?.id;
  });

  const userRecipes = recipes.filter(recipe => {
    if (currentUser?.role === 'owner') return true;
    return recipe.createdBy === currentUser?.id;
  });

  const filteredRecipes = userRecipes.filter(recipe =>
    recipe.menuName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const resetForm = () => {
    setFormData({ menuId: '', materials: [] });
    setIsAdding(false);
    setEditingRecipe(null);
  };

  const addMaterialRow = () => {
    setFormData(prev => ({
      ...prev,
      materials: [...prev.materials, { materialId: '', weight: '' }]
    }));
  };

  const removeMaterialRow = (index: number) => {
    setFormData(prev => ({
      ...prev,
      materials: prev.materials.filter((_, i) => i !== index)
    }));
  };

  const updateMaterialRow = (index: number, field: 'materialId' | 'weight', value: string) => {
    setFormData(prev => ({
      ...prev,
      materials: prev.materials.map((material, i) => 
        i === index ? { ...material, [field]: value } : material
      )
    }));
  };

  const calculateRecipeCost = (recipeMaterials: { materialId: string; weight: string }[]): { totalCost: number; materials: RecipeMaterial[] } => {
    let totalCost = 0;
    const processedMaterials: RecipeMaterial[] = [];

    recipeMaterials.forEach(({ materialId, weight }) => {
      const material = userMaterials.find(m => m.id === materialId);
      if (material && weight) {
        const weightNum = parseFloat(weight.replace(/\./g, ''));
        const cost = material.pricePerGram * weightNum;
        totalCost += cost;
        
        processedMaterials.push({
          materialId: material.id,
          materialName: material.name,
          weight: weightNum,
          cost
        });
      }
    });

    return { totalCost, materials: processedMaterials };
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.menuId || formData.materials.length === 0) {
      return;
    }

    const selectedMenu = userMenus.find(m => m.id === formData.menuId);
    if (!selectedMenu) return;

    const { totalCost, materials: recipeMaterials } = calculateRecipeCost(formData.materials);
    const profit = selectedMenu.price - totalCost;
    const profitMargin = selectedMenu.price > 0 ? (profit / selectedMenu.price) * 100 : 0;
    
    if (editingRecipe) {
      updateRecipe(editingRecipe.id, {
        menuId: formData.menuId,
        menuName: selectedMenu.name,
        materials: recipeMaterials,
        totalCost,
        profit,
        profitMargin
      });
    } else {
      addRecipe({
        menuId: formData.menuId,
        menuName: selectedMenu.name,
        materials: recipeMaterials,
        totalCost,
        profit,
        profitMargin,
        createdBy: currentUser?.id || ''
      });
    }
    
    resetForm();
  };

  const handleEdit = (recipe: Recipe) => {
    setEditingRecipe(recipe);
    setFormData({
      menuId: recipe.menuId,
      materials: recipe.materials.map(m => ({
        materialId: m.materialId,
        weight: m.weight.toString()
      }))
    });
    setIsAdding(true);
  };

  const handleDelete = (recipe: Recipe) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus resep "${recipe.menuName}"?`)) {
      deleteRecipe(recipe.id);
    }
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatNumber = (value: string): string => {
    const number = value.replace(/\D/g, '');
    return new Intl.NumberFormat('id-ID').format(parseInt(number) || 0);
  };

  // Live calculation preview
  const previewCalculation = () => {
    if (!formData.menuId) return null;
    
    const selectedMenu = userMenus.find(m => m.id === formData.menuId);
    if (!selectedMenu) return null;

    const { totalCost } = calculateRecipeCost(formData.materials);
    const profit = selectedMenu.price - totalCost;
    const profitMargin = selectedMenu.price > 0 ? (profit / selectedMenu.price) * 100 : 0;

    return { totalCost, profit, profitMargin, menuPrice: selectedMenu.price };
  };

  const preview = previewCalculation();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <ChefHat className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Kelola Resep</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Search & Add Button */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Cari resep..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
              />
            </div>
            
            <button
              onClick={() => setIsAdding(true)}
              disabled={userMenus.length === 0 || userMaterials.length === 0}
              className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus size={20} />
              <span>Tambah Resep</span>
            </button>
          </div>

          {/* Warning if no menu or materials */}
          {(userMenus.length === 0 || userMaterials.length === 0) && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
              <p className="text-yellow-800">
                {userMenus.length === 0 && 'Anda perlu menambahkan menu terlebih dahulu. '}
                {userMaterials.length === 0 && 'Anda perlu menambahkan bahan terlebih dahulu.'}
              </p>
            </div>
          )}

          {/* Add/Edit Form */}
          {isAdding && (
            <motion.form
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmit}
              className="bg-green-50 rounded-2xl p-6 mb-6 border border-green-200"
            >
              <h3 className="text-lg font-semibold text-green-800 mb-4">
                {editingRecipe ? 'Edit Resep' : 'Tambah Resep Baru'}
              </h3>
              
              {/* Menu Selection */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Pilih Menu *
                </label>
                <select
                  value={formData.menuId}
                  onChange={(e) => setFormData(prev => ({ ...prev, menuId: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500"
                  required
                >
                  <option value="">Pilih menu</option>
                  {userMenus.map(menu => (
                    <option key={menu.id} value={menu.id}>
                      {menu.name} - {formatCurrency(menu.price)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Materials */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Bahan-bahan *
                  </label>
                  <button
                    type="button"
                    onClick={addMaterialRow}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors duration-200"
                  >
                    <Plus size={16} />
                    <span>Tambah Bahan</span>
                  </button>
                </div>
                
                <div className="space-y-3">
                  {formData.materials.map((material, index) => (
                    <div key={index} className="flex gap-3 items-center bg-white p-4 rounded-xl border border-gray-200">
                      <div className="flex-1">
                        <select
                          value={material.materialId}
                          onChange={(e) => updateMaterialRow(index, 'materialId', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                          required
                        >
                          <option value="">Pilih bahan</option>
                          {userMaterials.map(mat => (
                            <option key={mat.id} value={mat.id}>
                              {mat.name} - {formatCurrency(mat.pricePerGram)}/gram
                            </option>
                          ))}
                        </select>
                      </div>
                      
                      <div className="w-32">
                        <input
                          type="text"
                          value={formatNumber(material.weight)}
                          onChange={(e) => updateMaterialRow(index, 'weight', e.target.value.replace(/\./g, ''))}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                          placeholder="Berat (gram)"
                          required
                        />
                      </div>
                      
                      <button
                        type="button"
                        onClick={() => removeMaterialRow(index)}
                        className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors duration-200"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  ))}
                  
                  {formData.materials.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      Belum ada bahan. Klik "Tambah Bahan" untuk menambahkan.
                    </div>
                  )}
                </div>
              </div>

              {/* Live Calculation Preview */}
              {preview && (
                <div className="mb-6 p-4 bg-white rounded-xl border border-green-200">
                  <div className="flex items-center space-x-2 mb-3">
                    <Calculator className="text-green-600" size={20} />
                    <h4 className="text-sm font-medium text-gray-700">Preview Perhitungan:</h4>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Harga Menu:</span>
                      <p className="font-semibold text-blue-600">
                        {formatCurrency(preview.menuPrice)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">Biaya Bahan:</span>
                      <p className="font-semibold text-orange-600">
                        {formatCurrency(preview.totalCost)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">Keuntungan:</span>
                      <p className={`font-semibold ${preview.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(preview.profit)}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">Margin:</span>
                      <p className={`font-semibold ${preview.profitMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {preview.profitMargin.toFixed(1)}%
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition-colors duration-200"
                >
                  {editingRecipe ? 'Update Resep' : 'Tambah Resep'}
                </button>
              </div>
            </motion.form>
          )}

          {/* Recipe List */}
          <div className="space-y-4">
            {filteredRecipes.length === 0 ? (
              <div className="text-center py-12">
                <ChefHat className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">
                  {searchTerm ? 'Resep tidak ditemukan' : 'Belum ada resep'}
                </p>
              </div>
            ) : (
              filteredRecipes.map((recipe, index) => (
                <motion.div
                  key={recipe.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-200"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{recipe.menuName}</h3>
                      
                      {/* Recipe Stats */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div className="bg-orange-50 p-3 rounded-xl">
                          <p className="text-sm text-gray-600 mb-1">Biaya Bahan</p>
                          <p className="text-lg font-bold text-orange-600">
                            {formatCurrency(recipe.totalCost)}
                          </p>
                        </div>
                        
                        <div className={`p-3 rounded-xl ${recipe.profit >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
                          <p className="text-sm text-gray-600 mb-1">Keuntungan</p>
                          <p className={`text-lg font-bold ${recipe.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatCurrency(recipe.profit)}
                          </p>
                        </div>
                        
                        <div className={`p-3 rounded-xl ${recipe.profitMargin >= 0 ? 'bg-blue-50' : 'bg-red-50'}`}>
                          <p className="text-sm text-gray-600 mb-1">Margin</p>
                          <p className={`text-lg font-bold ${recipe.profitMargin >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                            {recipe.profitMargin.toFixed(1)}%
                          </p>
                        </div>
                      </div>

                      {/* Materials List */}
                      <div className="bg-gray-50 p-4 rounded-xl">
                        <h4 className="text-sm font-medium text-gray-700 mb-2">Bahan-bahan:</h4>
                        <div className="space-y-2">
                          {recipe.materials.map((material, idx) => (
                            <div key={idx} className="flex justify-between items-center text-sm">
                              <span className="text-gray-600">{material.materialName}</span>
                              <div className="text-right">
                                <span className="font-medium">{material.weight.toLocaleString('id-ID')} gram</span>
                                <span className="text-gray-500 ml-2">({formatCurrency(material.cost)})</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-500 mt-3">
                        Dibuat: {new Date(recipe.createdAt).toLocaleDateString('id-ID')}
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <button
                        onClick={() => handleEdit(recipe)}
                        className="p-2 bg-blue-100 text-blue-600 rounded-xl hover:bg-blue-200 transition-colors duration-200"
                        title="Edit resep"
                      >
                        <Edit3 size={16} />
                      </button>
                      <button
                        onClick={() => handleDelete(recipe)}
                        className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors duration-200"
                        title="Hapus resep"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default RecipeManagement;