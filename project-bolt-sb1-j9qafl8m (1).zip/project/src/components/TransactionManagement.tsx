import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, DollarSign, ShoppingCart, CreditCard, Banknote, Package2 } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';

interface TransactionManagementProps {
  onClose: () => void;
}

const TransactionManagement: React.FC<TransactionManagementProps> = ({ onClose }) => {
  const { menus, addTransaction, currentUser } = useDatabase();
  const [transactionType, setTransactionType] = useState<'income' | 'expense'>('income');
  const [isWholesale, setIsWholesale] = useState(false);
  const [formData, setFormData] = useState({
    menuId: '',
    amount: '',
    customPrice: '',
    paymentMethod: 'cash' as 'qris' | 'cash',
    description: ''
  });

  // Filter menus based on user permissions
  const userMenus = menus.filter(menu => {
    if (currentUser?.role === 'owner') return true;
    return menu.createdBy === currentUser?.id;
  });

  const resetForm = () => {
    setFormData({
      menuId: '',
      amount: '',
      customPrice: '',
      paymentMethod: 'cash',
      description: ''
    });
    setIsWholesale(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // For employees, only allow income transactions
    if (currentUser?.role === 'employee' && transactionType === 'expense') {
      return;
    }
    
    if (transactionType === 'income' && !formData.menuId && !isWholesale) {
      return;
    }
    
    if (!formData.amount.trim()) {
      return;
    }

    const amount = parseFloat(formData.amount.replace(/\./g, ''));
    let cups = 0;
    let menuName = '';
    let finalAmount = amount;

    if (transactionType === 'income') {
      if (isWholesale) {
        // Wholesale transaction with custom pricing
        const customPrice = parseFloat(formData.customPrice.replace(/\./g, ''));
        if (customPrice > 0) {
          cups = Math.floor(amount / customPrice);
          finalAmount = cups * customPrice;
        }
        menuName = 'Grosir';
      } else if (formData.menuId) {
        // Regular menu transaction
        const selectedMenu = userMenus.find(m => m.id === formData.menuId);
        if (selectedMenu) {
          cups = Math.floor(amount / selectedMenu.price);
          finalAmount = cups * selectedMenu.price;
          menuName = selectedMenu.name;
        }
      }
    }

    addTransaction({
      type: transactionType,
      menuId: transactionType === 'income' && !isWholesale ? formData.menuId : undefined,
      menuName: transactionType === 'income' ? menuName : undefined,
      amount: finalAmount,
      cups: transactionType === 'income' ? cups : undefined,
      paymentMethod: transactionType === 'income' ? formData.paymentMethod : undefined,
      isWholesale: transactionType === 'income' ? isWholesale : undefined,
      customPrice: isWholesale ? parseFloat(formData.customPrice.replace(/\./g, '')) : undefined,
      description: formData.description.trim() || undefined,
      createdBy: currentUser?.id || '',
      createdByRole: currentUser?.role || 'employee'
    });
    
    resetForm();
    onClose();
  };

  const formatNumber = (value: string): string => {
    const number = value.replace(/\D/g, '');
    return new Intl.NumberFormat('id-ID').format(parseInt(number) || 0);
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  // Calculate preview
  const getPreview = () => {
    const amount = parseFloat(formData.amount.replace(/\./g, '')) || 0;
    
    if (transactionType === 'expense') {
      return { amount, cups: 0, total: amount };
    }

    if (isWholesale) {
      const customPrice = parseFloat(formData.customPrice.replace(/\./g, '')) || 0;
      const cups = customPrice > 0 ? Math.floor(amount / customPrice) : 0;
      const total = cups * customPrice;
      return { amount: total, cups, total, pricePerCup: customPrice };
    }

    if (formData.menuId) {
      const selectedMenu = userMenus.find(m => m.id === formData.menuId);
      if (selectedMenu) {
        const cups = Math.floor(amount / selectedMenu.price);
        const total = cups * selectedMenu.price;
        return { amount: total, cups, total, pricePerCup: selectedMenu.price };
      }
    }

    return { amount: 0, cups: 0, total: 0 };
  };

  const preview = getPreview();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                {transactionType === 'income' ? (
                  <DollarSign className="text-white" size={20} />
                ) : (
                  <ShoppingCart className="text-white" size={20} />
                )}
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">
                {transactionType === 'income' ? 'Tambah Pemasukan' : 'Tambah Pengeluaran'}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Transaction Type Toggle - Hide for employees */}
          {currentUser?.role !== 'employee' && (
            <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
              <button
                type="button"
                onClick={() => setTransactionType('income')}
                className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-semibold transition-all duration-200 ${
                  transactionType === 'income'
                    ? 'bg-green-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <DollarSign size={20} />
                <span>Pemasukan</span>
              </button>
              <button
                type="button"
                onClick={() => setTransactionType('expense')}
                className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-semibold transition-all duration-200 ${
                  transactionType === 'expense'
                    ? 'bg-red-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-gray-800'
                }`}
              >
                <ShoppingCart size={20} />
                <span>Pengeluaran</span>
              </button>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Income specific fields */}
            {transactionType === 'income' && (
              <>
                {/* Wholesale Toggle - Hide for employees */}
                {currentUser?.role !== 'employee' && (
                  <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl border border-blue-200">
                    <div className="flex items-center space-x-3">
                      <Package2 className="text-blue-600" size={20} />
                      <div>
                        <p className="font-semibold text-blue-800">Mode Grosir</p>
                        <p className="text-sm text-blue-600">Harga khusus untuk pembelian dalam jumlah besar</p>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isWholesale}
                        onChange={(e) => setIsWholesale(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                )}

                {/* Menu Selection (only if not wholesale) */}
                {!isWholesale && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pilih Menu *
                    </label>
                    <select
                      value={formData.menuId}
                      onChange={(e) => setFormData(prev => ({ ...prev, menuId: e.target.value }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Pilih menu</option>
                      {userMenus.map(menu => (
                        <option key={menu.id} value={menu.id}>
                          {menu.name} - {formatCurrency(menu.price)}
                        </option>
                      ))}
                    </select>
                    
                    {userMenus.length === 0 && (
                      <p className="text-sm text-red-600 mt-1">
                        Anda perlu menambahkan menu terlebih dahulu
                      </p>
                    )}
                  </div>
                )}

                {/* Custom Price for Wholesale - Hide for employees */}
                {isWholesale && currentUser?.role !== 'employee' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Harga per Cup Grosir *
                    </label>
                    <input
                      type="text"
                      value={formatNumber(formData.customPrice)}
                      onChange={(e) => setFormData(prev => ({ ...prev, customPrice: e.target.value.replace(/\./g, '') }))}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Harga khusus per cup"
                      required
                    />
                  </div>
                )}

                {/* Payment Method */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Metode Pembayaran
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, paymentMethod: 'cash' }))}
                      className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl border-2 font-semibold transition-all duration-200 ${
                        formData.paymentMethod === 'cash'
                          ? 'border-green-500 bg-green-50 text-green-700'
                          : 'border-gray-300 text-gray-600 hover:border-gray-400'
                      }`}
                    >
                      <Banknote size={20} />
                      <span>Cash</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, paymentMethod: 'qris' }))}
                      className={`flex items-center justify-center space-x-2 py-3 px-4 rounded-xl border-2 font-semibold transition-all duration-200 ${
                        formData.paymentMethod === 'qris'
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-300 text-gray-600 hover:border-gray-400'
                      }`}
                    >
                      <CreditCard size={20} />
                      <span>QRIS</span>
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* Amount */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {transactionType === 'income' ? 'Total Pembayaran *' : 'Jumlah Pengeluaran *'}
              </label>
              <input
                type="text"
                value={formatNumber(formData.amount)}
                onChange={(e) => setFormData(prev => ({ ...prev, amount: e.target.value.replace(/\./g, '') }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="0"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Keterangan {transactionType === 'expense' ? '*' : '(Opsional)'}
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={3}
                placeholder={transactionType === 'income' ? 'Keterangan tambahan...' : 'Deskripsi pengeluaran...'}
                required={transactionType === 'expense'}
              />
            </div>

            {/* Preview */}
            {(formData.amount || formData.customPrice) && (
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Preview Transaksi:</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  {transactionType === 'income' && (
                    <>
                      <div>
                        <span className="text-gray-600">Jumlah Cup:</span>
                        <p className="font-semibold text-blue-600">{preview.cups} cup</p>
                      </div>
                      {preview.pricePerCup && (
                        <div>
                          <span className="text-gray-600">Harga per Cup:</span>
                          <p className="font-semibold text-green-600">
                            {formatCurrency(preview.pricePerCup)}
                          </p>
                        </div>
                      )}
                    </>
                  )}
                  <div>
                    <span className="text-gray-600">Total:</span>
                    <p className={`font-semibold ${transactionType === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                      {formatCurrency(preview.total)}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="flex justify-end space-x-3">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
              >
                Batal
              </button>
              <button
                type="submit"
                className={`px-6 py-3 text-white rounded-xl font-semibold transition-colors duration-200 ${
                  transactionType === 'income'
                    ? 'bg-green-600 hover:bg-green-700'
                    : 'bg-red-600 hover:bg-red-700'
                }`}
              >
                Tambah {transactionType === 'income' ? 'Pemasukan' : 'Pengeluaran'}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default TransactionManagement;