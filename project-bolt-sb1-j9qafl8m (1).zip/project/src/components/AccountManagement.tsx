import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, Users, Crown, Building2, User, Trash2, Eye, EyeOff } from 'lucide-react';
import { useDatabase } from '../contexts/DatabaseContext';
import { User as UserType } from '../types';

interface AccountManagementProps {
  onClose: () => void;
}

const AccountManagement: React.FC<AccountManagementProps> = ({ onClose }) => {
  const { users, register, deleteUser, currentUser } = useDatabase();
  const [isAdding, setIsAdding] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'franchise' as UserType['role']
  });

  // Only owner can access this component
  if (currentUser?.role !== 'owner') {
    return null;
  }

  const resetForm = () => {
    setFormData({ username: '', password: '', role: 'franchise' });
    setIsAdding(false);
    setShowPassword(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.username.trim() || !formData.password.trim()) {
      return;
    }

    const success = await register({
      username: formData.username.trim(),
      password: formData.password.trim(),
      role: formData.role,
      parentId: currentUser.id
    });

    if (success) {
      resetForm();
    }
  };

  const handleDelete = (user: UserType) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus akun "${user.username}"?`)) {
      deleteUser(user.id);
    }
  };

  const getRoleIcon = (role: UserType['role']) => {
    switch (role) {
      case 'owner':
        return <Crown className="text-yellow-600" size={20} />;
      case 'franchise':
        return <Building2 className="text-blue-600" size={20} />;
      case 'employee':
        return <User className="text-green-600" size={20} />;
      default:
        return <User className="text-gray-600" size={20} />;
    }
  };

  const getRoleColor = (role: UserType['role']) => {
    switch (role) {
      case 'owner':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'franchise':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'employee':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getRoleName = (role: UserType['role']) => {
    switch (role) {
      case 'owner':
        return 'Owner';
      case 'franchise':
        return 'Franchise';
      case 'employee':
        return 'Karyawan';
      default:
        return role;
    }
  };

  // Filter users created by current owner
  const managedUsers = users.filter(user => 
    user.id === currentUser.id || user.parentId === currentUser.id
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                <Users className="text-white" size={20} />
              </div>
              <h2 className="text-xl font-bold text-white font-poppins">Kelola Akun</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center hover:bg-opacity-30 transition-all duration-200"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="p-6 max-h-[calc(90vh-80px)] overflow-y-auto">
          {/* Add Account Button */}
          <div className="flex justify-end mb-6">
            <button
              onClick={() => setIsAdding(true)}
              className="flex items-center space-x-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors duration-200"
            >
              <Plus size={20} />
              <span>Tambah Akun</span>
            </button>
          </div>

          {/* Add Account Form */}
          {isAdding && (
            <motion.form
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleSubmit}
              className="bg-indigo-50 rounded-2xl p-6 mb-6 border border-indigo-200"
            >
              <h3 className="text-lg font-semibold text-indigo-800 mb-4">Tambah Akun Baru</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Username *
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="Username"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Password *
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                      className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      placeholder="Password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Role *
                  </label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value as UserType['role'] }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    required
                  >
                    <option value="franchise">Franchise</option>
                    <option value="employee">Karyawan</option>
                  </select>
                </div>
              </div>

              {/* Role Description */}
              <div className="mt-4 p-4 bg-white rounded-xl border border-indigo-200">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Deskripsi Role:</h4>
                {formData.role === 'franchise' && (
                  <p className="text-sm text-gray-600">
                    <strong>Franchise:</strong> Dapat mengelola menu, bahan, resep, transaksi, dan membuat akun karyawan. 
                    Tidak dapat mengakses data owner atau membuat akun franchise lain.
                  </p>
                )}
                {formData.role === 'employee' && (
                  <p className="text-sm text-gray-600">
                    <strong>Karyawan:</strong> Hanya dapat menambahkan transaksi pemasukan. 
                    Data akan masuk ke akun yang membuatnya (owner/franchise).
                  </p>
                )}
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-colors duration-200"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors duration-200"
                >
                  Tambah Akun
                </button>
              </div>
            </motion.form>
          )}

          {/* Users List */}
          <div className="space-y-4">
            {managedUsers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-500 text-lg">Belum ada akun yang dikelola</p>
              </div>
            ) : (
              managedUsers.map((user, index) => (
                <motion.div
                  key={user.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-200"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center">
                        {getRoleIcon(user.role)}
                      </div>
                      
                      <div>
                        <div className="flex items-center space-x-3 mb-1">
                          <h3 className="text-lg font-semibold text-gray-900">{user.username}</h3>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getRoleColor(user.role)}`}>
                            {getRoleName(user.role)}
                          </span>
                          {user.id === currentUser.id && (
                            <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full font-medium">
                              Anda
                            </span>
                          )}
                        </div>
                        
                        <div className="text-sm text-gray-500 space-y-1">
                          <p>Dibuat: {new Date(user.createdAt).toLocaleDateString('id-ID')}</p>
                          {user.parentId && (
                            <p>Dibuat oleh: {users.find(u => u.id === user.parentId)?.username || 'Unknown'}</p>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {user.id !== currentUser.id && (
                      <button
                        onClick={() => handleDelete(user)}
                        className="p-2 bg-red-100 text-red-600 rounded-xl hover:bg-red-200 transition-colors duration-200"
                        title="Hapus akun"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {/* Account Statistics */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
              <div className="flex items-center space-x-2 mb-2">
                <Crown className="text-yellow-600" size={20} />
                <h4 className="font-semibold text-yellow-800">Owner</h4>
              </div>
              <p className="text-2xl font-bold text-yellow-600">
                {managedUsers.filter(u => u.role === 'owner').length}
              </p>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-xl border border-blue-200">
              <div className="flex items-center space-x-2 mb-2">
                <Building2 className="text-blue-600" size={20} />
                <h4 className="font-semibold text-blue-800">Franchise</h4>
              </div>
              <p className="text-2xl font-bold text-blue-600">
                {managedUsers.filter(u => u.role === 'franchise').length}
              </p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-xl border border-green-200">
              <div className="flex items-center space-x-2 mb-2">
                <User className="text-green-600" size={20} />
                <h4 className="font-semibold text-green-800">Karyawan</h4>
              </div>
              <p className="text-2xl font-bold text-green-600">
                {managedUsers.filter(u => u.role === 'employee').length}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default AccountManagement;