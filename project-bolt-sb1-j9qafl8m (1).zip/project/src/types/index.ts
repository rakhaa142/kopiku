export interface User {
  id: string;
  username: string;
  password: string;
  role: 'owner' | 'franchise' | 'employee';
  parentId?: string; // ID dari user yang membuat akun ini
  createdAt: Date;
  updatedAt: Date;
}

export interface Menu {
  id: string;
  name: string;
  price: number;
  category?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Material {
  id: string;
  name: string;
  totalPrice: number;
  totalWeight: number;
  pricePerGram: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Recipe {
  id: string;
  menuId: string;
  menuName: string;
  materials: RecipeMaterial[];
  totalCost: number;
  profit: number;
  profitMargin: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface RecipeMaterial {
  materialId: string;
  materialName: string;
  weight: number;
  cost: number;
}

export interface Transaction {
  id: string;
  type: 'income' | 'expense';
  menuId?: string;
  menuName?: string;
  amount: number;
  cups?: number;
  paymentMethod?: 'qris' | 'cash';
  isWholesale?: boolean;
  customPrice?: number;
  description?: string;
  createdBy: string;
  createdByRole: 'owner' | 'franchise' | 'employee';
  createdAt: Date;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  image?: string;
  isApproved: boolean;
  createdAt: Date;
}

export interface Analytics {
  totalIncome: number;
  totalExpense: number;
  totalProfit: number;
  totalCups: number;
  todayIncome: number;
  todayExpense: number;
  todayProfit: number;
  weeklyData: DailyData[];
}

export interface DailyData {
  date: string;
  income: number;
  expense: number;
  profit: number;
  trend: 'up' | 'down' | 'neutral';
}

export type TimeFilter = 'today' | 'thisMonth' | 'lastMonth' | 'thisYear' | 'lastYear';

export interface DatabaseState {
  users: User[];
  menus: Menu[];
  materials: Material[];
  recipes: Recipe[];
  transactions: Transaction[];
  reviews: Review[];
  currentUser: User | null;
}