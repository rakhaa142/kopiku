import React, { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { DatabaseProvider } from './contexts/DatabaseContext';
import IntroAnimation from './components/IntroAnimation';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import Portfolio from './components/Portfolio';

function App() {
  const [currentView, setCurrentView] = useState<'intro' | 'login' | 'dashboard' | 'portfolio'>('portfolio');

  const handleIntroComplete = () => {
    setCurrentView('portfolio');
  };

  const handleLoginSuccess = () => {
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setCurrentView('portfolio');
  };

  const handleLoginClick = () => {
    setCurrentView('login');
  };

  const handleBackToPortfolio = () => {
    setCurrentView('portfolio');
  };

  return (
    <DatabaseProvider>
      <div className="min-h-screen">
        {currentView === 'intro' && (
          <IntroAnimation onComplete={handleIntroComplete} />
        )}
        
        {currentView === 'portfolio' && (
          <Portfolio onLoginClick={handleLoginClick} />
        )}
        
        {currentView === 'login' && (
          <LoginPage 
            onLoginSuccess={handleLoginSuccess} 
            onBackToPortfolio={handleBackToPortfolio}
          />
        )}
        
        {currentView === 'dashboard' && (
          <Dashboard onLogout={handleLogout} />
        )}
        
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#363636',
              color: '#fff',
              borderRadius: '12px',
              padding: '16px',
              fontSize: '14px',
              fontWeight: '500',
            },
            success: {
              iconTheme: {
                primary: '#10B981',
                secondary: '#fff',
              },
            },
            error: {
              iconTheme: {
                primary: '#EF4444',
                secondary: '#fff',
              },
            },
          }}
        />
      </div>
    </DatabaseProvider>
  );
}

export default App;